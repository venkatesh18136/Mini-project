"""
Browser channel — REAL, deterministic event logging.

The exam-taking web page instruments the DOM (visibilitychange, blur,
copy, paste, contextmenu, fullscreenchange, devtools-detection tricks) and
posts each occurrence here. No inference is needed - these are concrete
browser events - so this module just validates the event type.
"""

ALLOWED_BROWSER_EVENTS = {
    "tab_switch",
    "window_blur",
    "copy_detected",
    "paste_detected",
    "devtools_opened",
    "fullscreen_exit",
    "right_click_attempt",
}


def is_valid_event(event_type: str) -> bool:
    return event_type in ALLOWED_BROWSER_EVENTS
