"""
Behavior channel — REAL heuristics derived from actual activity timestamps.

Behavior Analysis (per architecture diagram): Pattern & Anomaly Detection.
Covers the "User Behavior" data-collection group: Idle Time, Rapid
Answering, Backtracking, Abnormal Patterns. Unlike the audio/screen
heuristics, these are computed directly from real, unambiguous data the
backend already has (event/answer timestamps) rather than approximated —
there's no simulation involved, just threshold logic.
"""
import datetime
from typing import Any, Dict, List, Optional

from app.config import settings
from app.utils import utcnow


def check_idle(last_activity_at: Optional[datetime.datetime], now: Optional[datetime.datetime] = None) -> Dict[str, Any]:
    now = now or utcnow()
    findings: List[Dict[str, Any]] = []
    if last_activity_at is not None:
        idle_seconds = (now - last_activity_at).total_seconds()
        if idle_seconds >= settings.IDLE_SECONDS_THRESHOLD:
            findings.append({
                "event": "idle_time_exceeded", "confidence": 0.75,
                "details": {"idle_seconds": round(idle_seconds, 1)},
            })
    return {"findings": findings}


def check_answer_submission(
    seconds_since_last_action: float,
    is_edit: bool,
) -> Dict[str, Any]:
    findings: List[Dict[str, Any]] = []

    if seconds_since_last_action < settings.RAPID_ANSWER_SECONDS_THRESHOLD:
        findings.append({
            "event": "rapid_answering_detected", "confidence": 0.55,
            "details": {"seconds_since_last_action": round(seconds_since_last_action, 2)},
        })

    if is_edit:
        findings.append({
            "event": "backtracking_detected", "confidence": 0.50,
            "details": {},
        })

    return {"findings": findings}
