"""
Plagiarism / answer-similarity channel — REAL, basic NLP.

Compares every pair of student answers to the same exam question using
TF-IDF vectorization + cosine similarity (scikit-learn). This is a
legitimate, lightweight text-similarity algorithm suitable for a minor
project (no external API calls, runs fully offline).
"""
from typing import List

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def compute_similarity_matrix(texts: List[str]) -> List[List[float]]:
    """Returns an NxN similarity matrix for the given list of answer texts."""
    if len(texts) < 2:
        return []

    # Guard against all-empty / whitespace-only answers which break TF-IDF
    cleaned = [t if t and t.strip() else " " for t in texts]

    vectorizer = TfidfVectorizer(stop_words="english")
    tfidf_matrix = vectorizer.fit_transform(cleaned)
    similarity_matrix = cosine_similarity(tfidf_matrix)
    return similarity_matrix.tolist()
