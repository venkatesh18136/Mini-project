"""
Audio channel — SIMULATED/heuristic detection.

Audio Analysis (per architecture diagram): VAD, Noise & Anomaly Detection.

Real speech recognition / speaker diarization is out of scope for this
project. Instead, the client-side browser sends periodic volume-meter
readings (Web Audio API, 0-100 scale) and an optional lightweight
voice-count estimate, and we apply simple, explainable thresholds. This
keeps the channel dependency-free while still demonstrating VAD-style
(voice activity detection) logic; swap in a real diarization model behind
the same function signature for production use.
"""
from typing import Any, Dict, List, Optional

AMPLITUDE_TALK_THRESHOLD = 55.0     # sustained level above this may indicate talking (VAD)
SUSTAINED_SECONDS_THRESHOLD = 3.0
SPIKE_THRESHOLD = 85.0              # sudden loud noise (Noise/Anomaly Detection)


def analyze_audio_sample(
    amplitude: float,
    sustained_seconds: float = 0.0,
    voice_count_estimate: Optional[int] = None,
) -> Dict[str, Any]:
    findings: List[Dict[str, Any]] = []

    if amplitude >= SPIKE_THRESHOLD:
        findings.append({"event": "audio_spike_detected", "confidence": 0.60,
                          "details": {"amplitude": amplitude}})
    elif amplitude >= AMPLITUDE_TALK_THRESHOLD and sustained_seconds >= SUSTAINED_SECONDS_THRESHOLD:
        findings.append({"event": "voice_activity_detected", "confidence": 0.65,
                          "details": {"amplitude": amplitude, "sustained_seconds": sustained_seconds}})

    if voice_count_estimate is not None and voice_count_estimate > 1:
        findings.append({"event": "multiple_voice_detected", "confidence": 0.60,
                          "details": {"voice_count_estimate": voice_count_estimate}})

    return {"findings": findings}
