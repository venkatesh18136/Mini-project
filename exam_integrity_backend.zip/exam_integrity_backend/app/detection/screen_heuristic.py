"""
Screen channel — SIMULATED/heuristic detection (Screen Analysis: Event Detection Engine).

Covers the "Screen Activity" data-collection group from the architecture
diagram together with process/app-level checks. Tab switch, fullscreen
exit, copy/paste, right-click, and window-focus events are REAL and
deterministic (see browser_events.py) — this module adds the heuristic
part: checking client-reported window titles against a blocklist and
flagging multiple monitors. A real implementation would need a native
desktop agent to enumerate actual running processes.
"""
from typing import Any, Dict, List

BLOCKED_KEYWORDS = [
    "whatsapp", "telegram", "discord", "messenger", "chatgpt", "bard",
    "teamviewer", "anydesk", "chrome remote desktop", "zoom", "skype",
    "chegg", "quora", "course hero",
]


def analyze_screen_metadata(active_window_titles: List[str], monitor_count: int = 1) -> Dict[str, Any]:
    findings: List[Dict[str, Any]] = []

    titles_lower = " ".join(active_window_titles).lower()
    matched = [kw for kw in BLOCKED_KEYWORDS if kw in titles_lower]

    if matched:
        findings.append({"event": "prohibited_application_detected", "confidence": 0.80,
                          "details": {"matched_keywords": matched}})
    if monitor_count > 1:
        findings.append({"event": "multiple_monitors_suspected", "confidence": 0.70,
                          "details": {"monitor_count": monitor_count}})

    return {"findings": findings}
