"""
Video / Visual channel.

Video Analysis (per architecture diagram): YOLO / OpenCV / MediaPipe.

- Face detection & counting is REAL: OpenCV Haar-cascade classifier (bundled
  with opencv-python, no external model download required).
- Gaze / head-pose is a REAL but lightweight heuristic derived from the
  actual detected face position: how far the face bounding-box center sits
  from the frame center is used as a proxy for a turned head, without
  needing a landmark/pose model.
- Phone / object detection is a SIMULATED heuristic: contour-based
  rectangle detection tuned to flag phone-like dark rectangles. This is a
  stand-in for a real YOLOv8/MediaPipe object detector (see README for how
  to swap it in) — it is intentionally conservative and meant to be
  demonstrative, not production-accurate.

`analyze_frame` can surface more than one finding per frame (e.g. a face
that is both off-center AND a phone-shaped object below it), so it returns
a list of findings instead of a single event.
"""
from __future__ import annotations

import base64
from typing import Any, Dict, List

import cv2
import numpy as np

_FACE_CASCADE = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

BRIGHTNESS_THRESHOLD = 35.0     # mean grayscale pixel value below this => obstructed
GAZE_OFFSET_RATIO_THRESHOLD = 0.28  # face-center offset as a fraction of frame width/height
PHONE_MIN_AREA_RATIO = 0.01
PHONE_MAX_AREA_RATIO = 0.12
PHONE_ASPECT_MIN = 1.6          # phones are visibly taller/wider than square
PHONE_ASPECT_MAX = 2.6
PHONE_DARKNESS_THRESHOLD = 70.0  # mean intensity inside the contour


def _decode_base64_image(b64_string: str) -> np.ndarray | None:
    if "," in b64_string:
        b64_string = b64_string.split(",", 1)[1]
    try:
        img_bytes = base64.b64decode(b64_string)
    except Exception:
        return None
    arr = np.frombuffer(img_bytes, dtype=np.uint8)
    return cv2.imdecode(arr, cv2.IMREAD_COLOR)


def _detect_phone_like_object(gray: np.ndarray) -> Dict[str, Any] | None:
    """Simulated/heuristic phone detection via dark-rectangle contour analysis."""
    h, w = gray.shape
    frame_area = float(h * w)

    _, thresh = cv2.threshold(gray, PHONE_DARKNESS_THRESHOLD, 255, cv2.THRESH_BINARY_INV)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for c in contours:
        area = cv2.contourArea(c)
        area_ratio = area / frame_area
        if not (PHONE_MIN_AREA_RATIO <= area_ratio <= PHONE_MAX_AREA_RATIO):
            continue
        x, y, cw, ch = cv2.boundingRect(c)
        if cw == 0 or ch == 0:
            continue
        aspect = max(cw, ch) / min(cw, ch)
        if PHONE_ASPECT_MIN <= aspect <= PHONE_ASPECT_MAX:
            return {
                "bbox": [int(x), int(y), int(cw), int(ch)],
                "area_ratio": round(area_ratio, 4),
                "aspect_ratio": round(aspect, 2),
            }
    return None


def analyze_frame(b64_string: str) -> Dict[str, Any]:
    img = _decode_base64_image(b64_string)
    if img is None:
        return {"error": "invalid_image", "findings": []}

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape
    brightness = float(np.mean(gray))

    findings: List[Dict[str, Any]] = []

    # --- obstructed camera short-circuits everything else: nothing else is reliable in the dark
    if brightness < BRIGHTNESS_THRESHOLD:
        findings.append({"event": "camera_obstructed", "confidence": 0.70,
                          "details": {"brightness": round(brightness, 2)}})
        return {"num_faces": 0, "brightness": round(brightness, 2), "findings": findings}

    faces = _FACE_CASCADE.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(60, 60))
    num_faces = int(len(faces))

    if num_faces == 0:
        findings.append({"event": "no_face_detected", "confidence": 0.90, "details": {}})
    elif num_faces > 1:
        findings.append({"event": "multiple_faces_detected", "confidence": 0.90,
                          "details": {"num_faces": num_faces}})
    else:
        # exactly one face — real gaze/head-turn heuristic based on its position
        x, y, fw, fh = faces[0]
        face_center_x = x + fw / 2.0
        face_center_y = y + fh / 2.0
        offset_x = abs(face_center_x - w / 2.0) / w
        offset_y = abs(face_center_y - h / 2.0) / h
        if offset_x > GAZE_OFFSET_RATIO_THRESHOLD or offset_y > GAZE_OFFSET_RATIO_THRESHOLD:
            findings.append({"event": "gaze_away_detected", "confidence": 0.55,
                              "details": {"offset_x": round(offset_x, 3), "offset_y": round(offset_y, 3)}})

    # --- phone/object heuristic runs regardless of face count
    phone = _detect_phone_like_object(gray)
    if phone:
        findings.append({"event": "phone_detected", "confidence": 0.45, "details": phone})

    return {"num_faces": num_faces, "brightness": round(brightness, 2), "findings": findings}
