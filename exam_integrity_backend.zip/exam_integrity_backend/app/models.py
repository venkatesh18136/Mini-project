import datetime
from app.utils import utcnow
import enum

from sqlalchemy import (
    Column, Integer, String, Float, Boolean, ForeignKey, DateTime, Text, JSON,
    Enum as SAEnum,
)
from sqlalchemy.orm import relationship

from app.database import Base


class RoleEnum(str, enum.Enum):
    student = "student"
    proctor = "proctor"
    admin = "admin"


class SessionStatus(str, enum.Enum):
    not_started = "not_started"
    in_progress = "in_progress"
    completed = "completed"
    terminated = "terminated"


class RiskLevel(str, enum.Enum):
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"


class ReviewDecision(str, enum.Enum):
    clear = "clear"
    suspicious = "suspicious"
    malpractice_confirmed = "malpractice_confirmed"


# ---------------------------------------------------------------- users ----

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=False)
    email = Column(String(120), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(SAEnum(RoleEnum), default=RoleEnum.student, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=utcnow)

    sessions = relationship("ExamSession", back_populates="student")


# ---------------------------------------------------------------- exams ----

class Exam(Base):
    __tablename__ = "exams"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(200), nullable=False)
    description = Column(Text, default="")
    duration_minutes = Column(Integer, default=60)
    created_by = Column(Integer, ForeignKey("users.id"))
    plagiarism_threshold = Column(Float, default=0.80)
    created_at = Column(DateTime, default=utcnow)

    enrollments = relationship("ExamEnrollment", back_populates="exam", cascade="all, delete-orphan")
    sessions = relationship("ExamSession", back_populates="exam", cascade="all, delete-orphan")
    questions = relationship("Question", back_populates="exam", cascade="all, delete-orphan")


class Question(Base):
    """Exam Service — question bank for an exam."""
    __tablename__ = "questions"

    id = Column(Integer, primary_key=True, index=True)
    exam_id = Column(Integer, ForeignKey("exams.id"))
    question_text = Column(Text, nullable=False)
    question_order = Column(Integer, default=1)
    max_marks = Column(Float, default=1.0)

    exam = relationship("Exam", back_populates="questions")


class ExamEnrollment(Base):
    __tablename__ = "exam_enrollments"

    id = Column(Integer, primary_key=True, index=True)
    exam_id = Column(Integer, ForeignKey("exams.id"))
    student_id = Column(Integer, ForeignKey("users.id"))

    exam = relationship("Exam", back_populates="enrollments")


# ------------------------------------------------------------- sessions ----

class ExamSession(Base):
    __tablename__ = "exam_sessions"

    id = Column(Integer, primary_key=True, index=True)
    exam_id = Column(Integer, ForeignKey("exams.id"))
    student_id = Column(Integer, ForeignKey("users.id"))
    status = Column(SAEnum(SessionStatus), default=SessionStatus.not_started, nullable=False)
    integrity_score = Column(Float, default=100.0)
    risk_level = Column(SAEnum(RiskLevel), default=RiskLevel.low, nullable=False)
    start_time = Column(DateTime, nullable=True)
    end_time = Column(DateTime, nullable=True)
    last_activity_at = Column(DateTime, default=utcnow)

    exam = relationship("Exam", back_populates="sessions")
    student = relationship("User", back_populates="sessions")
    events = relationship("MonitoringEvent", back_populates="session", cascade="all, delete-orphan")
    incidents = relationship("Incident", back_populates="session", cascade="all, delete-orphan")
    risk_history = relationship("RiskScoreHistory", back_populates="session", cascade="all, delete-orphan")
    review = relationship("Review", back_populates="session", uselist=False, cascade="all, delete-orphan")


# --------------------------------------------- events / risk / incidents ----

class MonitoringEvent(Base):
    """Raw + processed events from all channels: video | audio | screen | behavior."""
    __tablename__ = "monitoring_events"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("exam_sessions.id"))
    channel = Column(String(30))       # video | audio | screen | behavior
    event_type = Column(String(60))
    severity = Column(String(20))      # low | medium | high | critical
    confidence = Column(Float, default=1.0)
    details = Column(JSON, default=dict)
    reasons = Column(JSON, default=list)     # Explainable Output — human-readable reasons
    score_impact = Column(Float, default=0.0)
    timestamp = Column(DateTime, default=utcnow)

    session = relationship("ExamSession", back_populates="events")


class RiskScoreHistory(Base):
    """Data Storage: risk_scores — a time series of the running integrity score,
    used to render 'Risk Trends' charts and the session timeline."""
    __tablename__ = "risk_scores"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("exam_sessions.id"))
    event_id = Column(Integer, ForeignKey("monitoring_events.id"), nullable=True)
    score = Column(Float)
    risk_level = Column(SAEnum(RiskLevel))
    timestamp = Column(DateTime, default=utcnow)

    session = relationship("ExamSession", back_populates="risk_history")


class Incident(Base):
    __tablename__ = "incidents"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("exam_sessions.id"))
    title = Column(String(200))
    description = Column(Text)
    channel = Column(String(30))
    severity = Column(String(20))
    reasons = Column(JSON, default=list)
    resolved = Column(Boolean, default=False)
    created_at = Column(DateTime, default=utcnow)

    session = relationship("ExamSession", back_populates="incidents")


class Review(Base):
    """Data Storage: reviews — the human-in-the-loop decision for a session."""
    __tablename__ = "reviews"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("exam_sessions.id"), unique=True)
    reviewer_id = Column(Integer, ForeignKey("users.id"))
    decision = Column(SAEnum(ReviewDecision), default=ReviewDecision.suspicious)
    comments = Column(Text, default="")
    created_at = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow)

    session = relationship("ExamSession", back_populates="review")


# ------------------------------------------------------ answers / plagiarism ----

class AnswerSubmission(Base):
    __tablename__ = "answer_submissions"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("exam_sessions.id"))
    question_id = Column(String(50))
    answer_text = Column(Text)
    is_edit = Column(Boolean, default=False)   # True if this question was already answered before (backtracking)
    submitted_at = Column(DateTime, default=utcnow)


class PlagiarismReport(Base):
    __tablename__ = "plagiarism_reports"

    id = Column(Integer, primary_key=True, index=True)
    exam_id = Column(Integer, ForeignKey("exams.id"))
    question_id = Column(String(50))
    submission_id_a = Column(Integer, ForeignKey("answer_submissions.id"))
    submission_id_b = Column(Integer, ForeignKey("answer_submissions.id"))
    student_a_id = Column(Integer, ForeignKey("users.id"))
    student_b_id = Column(Integer, ForeignKey("users.id"))
    similarity_score = Column(Float)
    flagged = Column(Boolean, default=False)
    created_at = Column(DateTime, default=utcnow)


# ------------------------------------------------- notifications / admin ----

class Notification(Base):
    """Notification Service — in-app alert inbox (persisted alongside the
    live WebSocket push, so a proctor who wasn't connected still sees it)."""
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    title = Column(String(200))
    message = Column(Text)
    severity = Column(String(20), default="info")
    read = Column(Boolean, default=False)
    created_at = Column(DateTime, default=utcnow)


class AuditLog(Base):
    """Admin — Audit Logs: records administrative / proctor decisions."""
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    actor_id = Column(Integer, ForeignKey("users.id"))
    action = Column(String(100))
    target_type = Column(String(50))
    target_id = Column(Integer, nullable=True)
    details = Column(JSON, default=dict)
    created_at = Column(DateTime, default=utcnow)


class SystemSetting(Base):
    """Admin — System Settings: simple editable key/value store."""
    __tablename__ = "system_settings"

    key = Column(String(100), primary_key=True)
    value = Column(String(500))
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow)
