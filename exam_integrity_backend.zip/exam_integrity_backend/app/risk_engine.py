"""
Evidence Fusion & Risk Scoring Pipeline.

Mirrors the architecture diagram's pipeline stages:

    Raw Events -> Preprocessing -> Evidence Fusion -> Temporal Analysis
    -> Risk Scoring -> Risk Level -> Explainable Output

Every channel (video / audio / screen / behavior) funnels its findings
through `record_event`, which runs all six stages and returns the stored
MonitoringEvent plus an Incident if severity crossed the alert threshold.
Each call also appends a row to RiskScoreHistory (Data Storage: risk_scores)
so the dashboard can chart a session's risk trend over time.
"""
import datetime
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy.orm import Session as DBSession

from app import models
from app.config import settings
from app.utils import utcnow

# ---- Stage: Risk Scoring reference table -----------------------------
# (channel, event_type) -> base point deduction
EVENT_WEIGHTS: Dict[Tuple[str, str], float] = {
    ("video", "camera_obstructed"): 6,
    ("video", "no_face_detected"): 8,
    ("video", "multiple_faces_detected"): 15,
    ("video", "gaze_away_detected"): 5,
    ("video", "phone_detected"): 14,

    ("audio", "audio_spike_detected"): 5,
    ("audio", "voice_activity_detected"): 8,
    ("audio", "multiple_voice_detected"): 12,

    ("screen", "tab_switch"): 5,
    ("screen", "window_blur"): 4,
    ("screen", "copy_detected"): 6,
    ("screen", "paste_detected"): 8,
    ("screen", "devtools_opened"): 20,
    ("screen", "fullscreen_exit"): 10,
    ("screen", "right_click_attempt"): 2,
    ("screen", "prohibited_application_detected"): 20,
    ("screen", "multiple_monitors_suspected"): 12,

    ("behavior", "idle_time_exceeded"): 6,
    ("behavior", "rapid_answering_detected"): 8,
    ("behavior", "backtracking_detected"): 4,
    ("behavior", "abnormal_pattern_detected"): 18,
}
DEFAULT_WEIGHT = 3.0
REPEAT_ESCALATION_MULTIPLIER = 1.5


def _preprocess(confidence: float, details: Optional[dict]) -> Tuple[float, dict]:
    """Stage: Preprocessing — clamp/clean inputs."""
    clean_confidence = max(0.0, min(1.0, confidence))
    clean_details = details or {}
    return clean_confidence, clean_details


def _recent_events(db: DBSession, session_id: int, window_seconds: int,
                    channel: Optional[str] = None, event_type: Optional[str] = None,
                    min_severity: Optional[List[str]] = None) -> List[models.MonitoringEvent]:
    cutoff = utcnow() - datetime.timedelta(seconds=window_seconds)
    q = db.query(models.MonitoringEvent).filter(
        models.MonitoringEvent.session_id == session_id,
        models.MonitoringEvent.timestamp >= cutoff,
    )
    if channel:
        q = q.filter(models.MonitoringEvent.channel == channel)
    if event_type:
        q = q.filter(models.MonitoringEvent.event_type == event_type)
    if min_severity:
        q = q.filter(models.MonitoringEvent.severity.in_(min_severity))
    return q.all()


def _temporal_analysis(db: DBSession, session: models.ExamSession, channel: str,
                        event_type: str, base_weight: float) -> Tuple[float, List[str]]:
    """Stage: Temporal Analysis — repeat-offense escalation within a rolling window."""
    reasons: List[str] = []
    repeats = _recent_events(db, session.id, settings.TEMPORAL_WINDOW_SECONDS, channel, event_type)
    weight = base_weight
    if len(repeats) + 1 >= settings.REPEAT_ESCALATION_COUNT:
        weight = round(base_weight * REPEAT_ESCALATION_MULTIPLIER, 2)
        reasons.append(
            f"'{event_type}' on {channel} channel repeated {len(repeats) + 1} times "
            f"in the last {settings.TEMPORAL_WINDOW_SECONDS}s — escalated."
        )
    return weight, reasons


def _severity_for_weight(weight: float) -> str:
    if weight >= 18:
        return "critical"
    if weight >= 12:
        return "high"
    if weight >= 6:
        return "medium"
    return "low"


def _risk_level_for_score(score: float) -> models.RiskLevel:
    if score >= settings.RISK_LOW_MIN:
        return models.RiskLevel.low
    if score >= settings.RISK_MEDIUM_MIN:
        return models.RiskLevel.medium
    if score >= settings.RISK_HIGH_MIN:
        return models.RiskLevel.high
    return models.RiskLevel.critical


def _log_risk_history(db: DBSession, session: models.ExamSession, event_id: Optional[int]) -> None:
    db.add(models.RiskScoreHistory(
        session_id=session.id, event_id=event_id,
        score=session.integrity_score, risk_level=session.risk_level,
    ))


def record_event(
    db: DBSession,
    session: models.ExamSession,
    channel: str,
    event_type: str,
    confidence: float = 1.0,
    details: Optional[dict] = None,
    _is_meta: bool = False,
) -> Tuple[models.MonitoringEvent, Optional[models.Incident]]:
    # Stage: Preprocessing
    confidence, details = _preprocess(confidence, details)
    base_weight = EVENT_WEIGHTS.get((channel, event_type), DEFAULT_WEIGHT)

    # Stage: Temporal Analysis
    escalated_weight, temporal_reasons = _temporal_analysis(db, session, channel, event_type, base_weight)

    # Stage: Risk Scoring
    weighted_impact = round(escalated_weight * confidence, 2)
    severity = _severity_for_weight(weighted_impact)

    # Stage: Explainable Output
    reasons = [
        f"Detected '{event_type}' on the {channel} channel with confidence {confidence:.2f} "
        f"(base weight {base_weight}, applied {weighted_impact})."
    ] + temporal_reasons

    event = models.MonitoringEvent(
        session_id=session.id, channel=channel, event_type=event_type,
        severity=severity, confidence=confidence, details=details,
        reasons=reasons, score_impact=weighted_impact,
    )
    db.add(event)

    # Stage: Risk Level
    session.integrity_score = round(max(0.0, min(100.0, session.integrity_score - weighted_impact)), 2)
    session.risk_level = _risk_level_for_score(session.integrity_score)
    session.last_activity_at = utcnow()

    db.flush()  # get event.id without a full commit yet
    _log_risk_history(db, session, event.id)

    incident = None
    if severity in ("high", "critical"):
        incident = models.Incident(
            session_id=session.id,
            title=event_type.replace("_", " ").title(),
            description=(
                f"Detected on '{channel}' channel with confidence {confidence:.2f}. "
                f"Session integrity score is now {session.integrity_score:.1f}."
            ),
            channel=channel, severity=severity, reasons=reasons,
        )
        db.add(incident)

    db.commit()
    db.refresh(event)
    db.refresh(session)
    if incident:
        db.refresh(incident)

    # Stage: Evidence Fusion — cross-channel correlation (skip for meta events to avoid recursion)
    if not _is_meta:
        _maybe_flag_abnormal_pattern(db, session)

    return event, incident


def _maybe_flag_abnormal_pattern(db: DBSession, session: models.ExamSession) -> None:
    """Evidence Fusion: if several high/critical events land across (possibly
    different) channels in a short window, raise a single fused
    'abnormal_pattern_detected' behavior event rather than letting the
    proctor piece it together manually."""
    recent_high = _recent_events(
        db, session.id, settings.TEMPORAL_WINDOW_SECONDS,
        min_severity=["high", "critical"],
    )
    if len(recent_high) < settings.CROSS_CHANNEL_ESCALATION_COUNT:
        return

    already_flagged = _recent_events(
        db, session.id, settings.TEMPORAL_WINDOW_SECONDS,
        channel="behavior", event_type="abnormal_pattern_detected",
    )
    if already_flagged:
        return

    channels_involved = sorted({e.channel for e in recent_high})
    record_event(
        db, session, "behavior", "abnormal_pattern_detected", confidence=0.80,
        details={"contributing_channels": channels_involved, "event_count": len(recent_high)},
        _is_meta=True,
    )
