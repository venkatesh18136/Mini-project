import datetime


def utcnow() -> datetime.datetime:
    """Current UTC time as a naive datetime (no tzinfo).

    Equivalent to the old `datetime.datetime.utcnow()`, which is deprecated
    in modern Python — this keeps every stored/compared timestamp in the
    same naive-UTC convention (mixing naive and timezone-aware datetimes
    raises a TypeError on comparison/subtraction, so all call sites use
    this helper rather than switching only some of them).
    """
    return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
