import csv
import io
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app import models, schemas, auth
from app.database import get_db
from app.routers.admin_routes import log_audit

router = APIRouter(prefix="/reports", tags=["reports"])


def _build_session_report(db: Session, session_id: int) -> schemas.SessionReportOut:
    session = db.query(models.ExamSession).filter(models.ExamSession.id == session_id).first()
    if not session:
        raise HTTPException(404, "Session not found")
    student = db.query(models.User).filter(models.User.id == session.student_id).first()
    events = (
        db.query(models.MonitoringEvent).filter(models.MonitoringEvent.session_id == session_id)
        .order_by(models.MonitoringEvent.timestamp).all()
    )
    incidents = db.query(models.Incident).filter(models.Incident.session_id == session_id).all()
    risk_trend = (
        db.query(models.RiskScoreHistory).filter(models.RiskScoreHistory.session_id == session_id)
        .order_by(models.RiskScoreHistory.timestamp).all()
    )
    review = db.query(models.Review).filter(models.Review.session_id == session_id).first()
    plagiarism_matches = (
        db.query(models.PlagiarismReport)
        .filter(
            (models.PlagiarismReport.student_a_id == session.student_id)
            | (models.PlagiarismReport.student_b_id == session.student_id),
            models.PlagiarismReport.exam_id == session.exam_id,
        )
        .all()
    )

    return schemas.SessionReportOut(
        session=session, student=student, events=events, incidents=incidents,
        risk_trend=[
            schemas.RiskTrendPointOut(timestamp=r.timestamp, score=r.score, risk_level=r.risk_level.value)
            for r in risk_trend
        ],
        review=review, plagiarism_matches=plagiarism_matches,
    )


@router.get("/session/{session_id}", response_model=schemas.SessionReportOut)
def get_session_report(
    session_id: int, db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    return _build_session_report(db, session_id)


@router.get("/session/{session_id}/pdf")
def get_session_report_pdf(
    session_id: int, db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas

    report = _build_session_report(db, session_id)

    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    width, height = A4
    y = height - 25 * mm

    def line(text, size=10, dy=6 * mm, bold=False):
        nonlocal y
        c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
        c.drawString(20 * mm, y, text[:110])
        y -= dy
        if y < 20 * mm:
            c.showPage()
            y = height - 25 * mm

    line("Exam Integrity — Session Report", 16, bold=True)
    line(f"Session ID: {report.session.id}    Exam ID: {report.session.exam_id}")
    line(f"Student: {report.student.name} <{report.student.email}>")
    line(f"Status: {report.session.status.value}    Risk level: {report.session.risk_level.value}")
    line(f"Final integrity score: {report.session.integrity_score:.1f} / 100")
    if report.review:
        line(f"Human review: {report.review.decision.value} — {report.review.comments}")
    line("")
    line(f"Incidents ({len(report.incidents)})", 12, bold=True)
    for inc in report.incidents:
        line(f"[{inc.severity.upper()}] {inc.title} — {inc.created_at.strftime('%Y-%m-%d %H:%M:%S')}")
    line("")
    line(f"Events ({len(report.events)})", 12, bold=True)
    for ev in report.events[:60]:
        line(f"{ev.timestamp.strftime('%H:%M:%S')}  {ev.channel:9s} {ev.event_type:30s} -{ev.score_impact}")
    if report.plagiarism_matches:
        line("")
        line("Plagiarism matches", 12, bold=True)
        for m in report.plagiarism_matches:
            line(f"Q{m.question_id}: similarity {m.similarity_score:.2f} "
                 f"({'FLAGGED' if m.flagged else 'ok'}) students {m.student_a_id}<->{m.student_b_id}")

    c.showPage()
    c.save()
    buf.seek(0)

    log_audit(db, user.id, "export_session_pdf", "session", session_id)
    return StreamingResponse(
        buf, media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=session_{session_id}_report.pdf"},
    )


@router.get("/exam/{exam_id}/csv")
def export_exam_csv(
    exam_id: int, db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    sessions = db.query(models.ExamSession).filter(models.ExamSession.exam_id == exam_id).all()

    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["session_id", "student_id", "student_name", "status", "integrity_score",
                      "risk_level", "open_incidents", "review_decision"])
    for s in sessions:
        student = db.query(models.User).filter(models.User.id == s.student_id).first()
        open_incidents = db.query(models.Incident).filter(
            models.Incident.session_id == s.id, models.Incident.resolved == False  # noqa: E712
        ).count()
        review = db.query(models.Review).filter(models.Review.session_id == s.id).first()
        writer.writerow([
            s.id, s.student_id, student.name if student else "", s.status.value,
            s.integrity_score, s.risk_level.value, open_incidents,
            review.decision.value if review else "",
        ])

    buf.seek(0)
    log_audit(db, user.id, "export_exam_csv", "exam", exam_id)
    return StreamingResponse(
        iter([buf.getvalue()]), media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=exam_{exam_id}_summary.csv"},
    )


@router.get("/session/{session_id}/risk-trend", response_model=List[schemas.RiskTrendPointOut])
def get_risk_trend(
    session_id: int, db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    rows = (
        db.query(models.RiskScoreHistory).filter(models.RiskScoreHistory.session_id == session_id)
        .order_by(models.RiskScoreHistory.timestamp).all()
    )
    return [schemas.RiskTrendPointOut(timestamp=r.timestamp, score=r.score, risk_level=r.risk_level.value) for r in rows]
