import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas, auth
from app.database import get_db
from app.utils import utcnow

router = APIRouter(tags=["sessions"])


@router.post("/sessions/start", response_model=schemas.SessionOut, status_code=201)
def start_session(
    payload: schemas.SessionStartRequest,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.student)),
):
    exam = db.query(models.Exam).filter(models.Exam.id == payload.exam_id).first()
    if not exam:
        raise HTTPException(404, "Exam not found")

    existing = (
        db.query(models.ExamSession)
        .filter(
            models.ExamSession.exam_id == payload.exam_id,
            models.ExamSession.student_id == user.id,
            models.ExamSession.status == models.SessionStatus.in_progress,
        )
        .first()
    )
    if existing:
        return existing

    session = models.ExamSession(
        exam_id=payload.exam_id,
        student_id=user.id,
        status=models.SessionStatus.in_progress,
        start_time=utcnow(),
    )
    db.add(session)
    db.commit()
    db.refresh(session)
    return session


@router.post("/sessions/{session_id}/end", response_model=schemas.SessionOut)
def end_session(session_id: int, db: Session = Depends(get_db), user: models.User = Depends(auth.get_current_user)):
    session = db.query(models.ExamSession).filter(models.ExamSession.id == session_id).first()
    if not session:
        raise HTTPException(404, "Session not found")
    if user.role == models.RoleEnum.student and session.student_id != user.id:
        raise HTTPException(403, "Not your session")

    session.status = models.SessionStatus.completed
    session.end_time = utcnow()
    db.commit()
    db.refresh(session)
    return session


@router.get("/sessions/{session_id}", response_model=schemas.SessionOut)
def get_session(session_id: int, db: Session = Depends(get_db), user: models.User = Depends(auth.get_current_user)):
    session = db.query(models.ExamSession).filter(models.ExamSession.id == session_id).first()
    if not session:
        raise HTTPException(404, "Session not found")
    if user.role == models.RoleEnum.student and session.student_id != user.id:
        raise HTTPException(403, "Not your session")
    return session


@router.get("/exams/{exam_id}/sessions", response_model=List[schemas.SessionOut])
def list_exam_sessions(
    exam_id: int,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    return db.query(models.ExamSession).filter(models.ExamSession.exam_id == exam_id).all()
