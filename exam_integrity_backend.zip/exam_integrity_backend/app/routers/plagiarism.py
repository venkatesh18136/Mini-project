import datetime
from collections import defaultdict
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas, auth, risk_engine
from app.database import get_db
from app.detection.plagiarism_check import compute_similarity_matrix
from app.detection import behavior_heuristic
from app.websocket_manager import manager
from app.utils import utcnow

router = APIRouter(tags=["plagiarism"])


@router.post("/sessions/{session_id}/answers", status_code=201)
async def submit_answer(
    session_id: int,
    payload: schemas.AnswerIn,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.student)),
):
    session = db.query(models.ExamSession).filter(models.ExamSession.id == session_id).first()
    if not session:
        raise HTTPException(404, "Session not found")
    if session.student_id != user.id:
        raise HTTPException(403, "Not your session")

    is_edit = (
        db.query(models.AnswerSubmission)
        .filter(models.AnswerSubmission.session_id == session_id,
                models.AnswerSubmission.question_id == payload.question_id)
        .first()
        is not None
    )

    now = utcnow()
    seconds_since_last_action = (now - session.last_activity_at).total_seconds() if session.last_activity_at else 999.0

    answer = models.AnswerSubmission(
        session_id=session_id, question_id=payload.question_id,
        answer_text=payload.answer_text, is_edit=is_edit,
    )
    db.add(answer)
    session.last_activity_at = now
    db.commit()
    db.refresh(answer)

    # Behavior channel — real heuristics on real timestamps (rapid answering / backtracking)
    result = behavior_heuristic.check_answer_submission(seconds_since_last_action, is_edit)
    for finding in result["findings"]:
        event, incident = risk_engine.record_event(
            db, session, "behavior", finding["event"], finding["confidence"], finding["details"]
        )
        await manager.broadcast(session.exam_id, {
            "type": "incident" if incident else "event",
            "session_id": session.id, "student_id": session.student_id,
            "channel": "behavior", "event_type": event.event_type, "severity": event.severity,
            "reasons": event.reasons, "integrity_score": session.integrity_score,
            "risk_level": session.risk_level.value, "incident_id": incident.id if incident else None,
        })

    return {"id": answer.id, "question_id": answer.question_id, "is_edit": is_edit, "submitted_at": answer.submitted_at}


@router.post("/exams/{exam_id}/plagiarism-check", response_model=List[schemas.PlagiarismReportOut])
def run_plagiarism_check(
    exam_id: int,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    exam = db.query(models.Exam).filter(models.Exam.id == exam_id).first()
    if not exam:
        raise HTTPException(404, "Exam not found")

    submissions = (
        db.query(models.AnswerSubmission)
        .join(models.ExamSession, models.ExamSession.id == models.AnswerSubmission.session_id)
        .filter(models.ExamSession.exam_id == exam_id)
        .all()
    )

    # group submissions by question so we only compare answers to the same question
    by_question = defaultdict(list)
    for sub in submissions:
        session = db.query(models.ExamSession).filter(models.ExamSession.id == sub.session_id).first()
        by_question[sub.question_id].append((sub, session.student_id))

    new_reports = []
    for question_id, entries in by_question.items():
        if len(entries) < 2:
            continue
        texts = [e[0].answer_text for e in entries]
        sim_matrix = compute_similarity_matrix(texts)

        for i in range(len(entries)):
            for j in range(i + 1, len(entries)):
                score = sim_matrix[i][j]
                flagged = score >= exam.plagiarism_threshold
                report = models.PlagiarismReport(
                    exam_id=exam_id,
                    question_id=question_id,
                    submission_id_a=entries[i][0].id,
                    submission_id_b=entries[j][0].id,
                    student_a_id=entries[i][1],
                    student_b_id=entries[j][1],
                    similarity_score=round(score, 4),
                    flagged=flagged,
                )
                db.add(report)
                new_reports.append(report)

    db.commit()
    for r in new_reports:
        db.refresh(r)
    return new_reports


@router.get("/exams/{exam_id}/plagiarism-report", response_model=List[schemas.PlagiarismReportOut])
def get_plagiarism_report(
    exam_id: int,
    flagged_only: bool = True,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    query = db.query(models.PlagiarismReport).filter(models.PlagiarismReport.exam_id == exam_id)
    if flagged_only:
        query = query.filter(models.PlagiarismReport.flagged == True)  # noqa: E712
    return query.all()
