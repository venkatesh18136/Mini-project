from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas, auth
from app.database import get_db

router = APIRouter(tags=["incidents"])


@router.get("/sessions/{session_id}/incidents", response_model=List[schemas.IncidentOut])
def list_session_incidents(
    session_id: int, db: Session = Depends(get_db), user: models.User = Depends(auth.get_current_user)
):
    session = db.query(models.ExamSession).filter(models.ExamSession.id == session_id).first()
    if not session:
        raise HTTPException(404, "Session not found")
    if user.role == models.RoleEnum.student and session.student_id != user.id:
        raise HTTPException(403, "Not your session")
    return db.query(models.Incident).filter(models.Incident.session_id == session_id).all()


@router.get("/exams/{exam_id}/incidents", response_model=List[schemas.IncidentOut])
def list_exam_incidents(
    exam_id: int,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    return (
        db.query(models.Incident)
        .join(models.ExamSession, models.ExamSession.id == models.Incident.session_id)
        .filter(models.ExamSession.exam_id == exam_id)
        .all()
    )


@router.patch("/incidents/{incident_id}/resolve", response_model=schemas.IncidentOut)
def resolve_incident(
    incident_id: int,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    incident = db.query(models.Incident).filter(models.Incident.id == incident_id).first()
    if not incident:
        raise HTTPException(404, "Incident not found")
    incident.resolved = True
    db.commit()
    db.refresh(incident)
    return incident
