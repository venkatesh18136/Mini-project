from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas, auth
from app.database import get_db

router = APIRouter(prefix="/admin", tags=["admin"])


def log_audit(db: Session, actor_id: int, action: str, target_type: str,
              target_id: Optional[int] = None, details: Optional[dict] = None) -> None:
    """Shared helper — any router can call this to record an admin/proctor decision."""
    db.add(models.AuditLog(
        actor_id=actor_id, action=action, target_type=target_type,
        target_id=target_id, details=details or {},
    ))
    db.commit()


# ---------------- User management ----------------

@router.get("/users", response_model=List[schemas.UserOut])
def list_users(db: Session = Depends(get_db), user: models.User = Depends(auth.require_role(models.RoleEnum.admin))):
    return db.query(models.User).all()


@router.patch("/users/{user_id}/deactivate", response_model=schemas.UserOut)
def deactivate_user(
    user_id: int, db: Session = Depends(get_db),
    admin: models.User = Depends(auth.require_role(models.RoleEnum.admin)),
):
    target = db.query(models.User).filter(models.User.id == user_id).first()
    if not target:
        raise HTTPException(404, "User not found")
    target.is_active = False
    db.commit()
    db.refresh(target)
    log_audit(db, admin.id, "deactivate_user", "user", user_id)
    return target


@router.patch("/users/{user_id}/activate", response_model=schemas.UserOut)
def activate_user(
    user_id: int, db: Session = Depends(get_db),
    admin: models.User = Depends(auth.require_role(models.RoleEnum.admin)),
):
    target = db.query(models.User).filter(models.User.id == user_id).first()
    if not target:
        raise HTTPException(404, "User not found")
    target.is_active = True
    db.commit()
    db.refresh(target)
    log_audit(db, admin.id, "activate_user", "user", user_id)
    return target


# ---------------- Audit logs ----------------

@router.get("/audit-logs", response_model=List[schemas.AuditLogOut])
def list_audit_logs(
    db: Session = Depends(get_db), admin: models.User = Depends(auth.require_role(models.RoleEnum.admin))
):
    return db.query(models.AuditLog).order_by(models.AuditLog.created_at.desc()).limit(500).all()


# ---------------- System settings ----------------

@router.get("/settings", response_model=List[schemas.SystemSettingOut])
def list_settings(db: Session = Depends(get_db), admin: models.User = Depends(auth.require_role(models.RoleEnum.admin))):
    return db.query(models.SystemSetting).all()


@router.put("/settings/{key}", response_model=schemas.SystemSettingOut)
def update_setting(
    key: str, payload: schemas.SystemSettingIn, db: Session = Depends(get_db),
    admin: models.User = Depends(auth.require_role(models.RoleEnum.admin)),
):
    setting = db.query(models.SystemSetting).filter(models.SystemSetting.key == key).first()
    if setting:
        setting.value = payload.value
    else:
        setting = models.SystemSetting(key=key, value=payload.value)
        db.add(setting)
    db.commit()
    db.refresh(setting)
    log_audit(db, admin.id, "update_setting", "system_setting", None, {"key": key, "value": payload.value})
    return setting
