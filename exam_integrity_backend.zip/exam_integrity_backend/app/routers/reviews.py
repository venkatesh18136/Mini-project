from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas, auth
from app.database import get_db
from app.routers.admin_routes import log_audit

router = APIRouter(tags=["reviews"])


@router.put("/sessions/{session_id}/review", response_model=schemas.ReviewOut)
def submit_review(
    session_id: int,
    payload: schemas.ReviewIn,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    session = db.query(models.ExamSession).filter(models.ExamSession.id == session_id).first()
    if not session:
        raise HTTPException(404, "Session not found")

    review = db.query(models.Review).filter(models.Review.session_id == session_id).first()
    if review:
        review.decision = payload.decision
        review.comments = payload.comments
        review.reviewer_id = user.id
    else:
        review = models.Review(
            session_id=session_id, reviewer_id=user.id,
            decision=payload.decision, comments=payload.comments,
        )
        db.add(review)

    db.commit()
    db.refresh(review)
    log_audit(db, user.id, "submit_review", "session", session_id, {"decision": payload.decision.value})
    return review


@router.get("/sessions/{session_id}/review", response_model=schemas.ReviewOut)
def get_review(
    session_id: int,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    review = db.query(models.Review).filter(models.Review.session_id == session_id).first()
    if not review:
        raise HTTPException(404, "No review submitted yet for this session")
    return review
