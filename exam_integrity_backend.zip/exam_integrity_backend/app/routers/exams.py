from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas, auth
from app.database import get_db

router = APIRouter(prefix="/exams", tags=["exams"])


@router.post("", response_model=schemas.ExamOut, status_code=201)
def create_exam(
    payload: schemas.ExamCreate,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    exam = models.Exam(
        title=payload.title,
        description=payload.description,
        duration_minutes=payload.duration_minutes,
        plagiarism_threshold=payload.plagiarism_threshold,
        created_by=user.id,
    )
    db.add(exam)
    db.commit()
    db.refresh(exam)
    return exam


@router.get("", response_model=List[schemas.ExamOut])
def list_exams(db: Session = Depends(get_db), user: models.User = Depends(auth.get_current_user)):
    return db.query(models.Exam).all()


@router.get("/{exam_id}", response_model=schemas.ExamOut)
def get_exam(exam_id: int, db: Session = Depends(get_db), user: models.User = Depends(auth.get_current_user)):
    exam = db.query(models.Exam).filter(models.Exam.id == exam_id).first()
    if not exam:
        raise HTTPException(404, "Exam not found")
    return exam


@router.patch("/{exam_id}", response_model=schemas.ExamOut)
def update_exam(
    exam_id: int,
    payload: schemas.ExamUpdate,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    exam = db.query(models.Exam).filter(models.Exam.id == exam_id).first()
    if not exam:
        raise HTTPException(404, "Exam not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(exam, field, value)
    db.commit()
    db.refresh(exam)
    return exam


# ---------------- Questions (Exam Service: question bank) ----------------

@router.post("/{exam_id}/questions", response_model=schemas.QuestionOut, status_code=201)
def add_question(
    exam_id: int,
    payload: schemas.QuestionCreate,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    exam = db.query(models.Exam).filter(models.Exam.id == exam_id).first()
    if not exam:
        raise HTTPException(404, "Exam not found")
    question = models.Question(
        exam_id=exam_id, question_text=payload.question_text,
        question_order=payload.question_order, max_marks=payload.max_marks,
    )
    db.add(question)
    db.commit()
    db.refresh(question)
    return question


@router.get("/{exam_id}/questions", response_model=List[schemas.QuestionOut])
def list_questions(exam_id: int, db: Session = Depends(get_db), user: models.User = Depends(auth.get_current_user)):
    return (
        db.query(models.Question)
        .filter(models.Question.exam_id == exam_id)
        .order_by(models.Question.question_order)
        .all()
    )


@router.post("/{exam_id}/enroll", status_code=201)
def enroll_students(
    exam_id: int,
    payload: schemas.EnrollRequest,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    exam = db.query(models.Exam).filter(models.Exam.id == exam_id).first()
    if not exam:
        raise HTTPException(404, "Exam not found")

    created = []
    for student_id in payload.student_ids:
        exists = (
            db.query(models.ExamEnrollment)
            .filter(models.ExamEnrollment.exam_id == exam_id, models.ExamEnrollment.student_id == student_id)
            .first()
        )
        if not exists:
            enrollment = models.ExamEnrollment(exam_id=exam_id, student_id=student_id)
            db.add(enrollment)
            created.append(student_id)

    db.commit()
    return {"enrolled": created}


@router.get("/{exam_id}/students")
def list_enrolled_students(
    exam_id: int,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    rows = (
        db.query(models.User)
        .join(models.ExamEnrollment, models.ExamEnrollment.student_id == models.User.id)
        .filter(models.ExamEnrollment.exam_id == exam_id)
        .all()
    )
    return [{"id": u.id, "name": u.name, "email": u.email} for u in rows]
