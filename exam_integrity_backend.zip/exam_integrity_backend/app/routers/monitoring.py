import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas, auth, risk_engine
from app.database import get_db
from app.detection import video_analysis, audio_heuristic, screen_heuristic, browser_events, behavior_heuristic
from app.integrations.storage_service import save_evidence_snapshot
from app.integrations.email_service import send_email_alert
from app.websocket_manager import manager
from app.utils import utcnow

router = APIRouter(prefix="/monitoring", tags=["monitoring"])


def _get_session_or_404(session_id: int, db: Session, user: models.User) -> models.ExamSession:
    session = db.query(models.ExamSession).filter(models.ExamSession.id == session_id).first()
    if not session:
        raise HTTPException(404, "Session not found")
    if user.role == models.RoleEnum.student and session.student_id != user.id:
        raise HTTPException(403, "Not your session")
    return session


async def _apply_finding(
    db: Session, session: models.ExamSession, channel: str, finding: dict,
    raw_frame_b64: str | None = None,
) -> models.MonitoringEvent:
    event, incident = risk_engine.record_event(
        db, session, channel, finding["event"], finding.get("confidence", 1.0), finding.get("details", {})
    )

    if incident:
        # Evidence storage: snapshot the frame that triggered a high/critical video incident.
        if channel == "video" and raw_frame_b64:
            path = save_evidence_snapshot(session.id, raw_frame_b64)
            if path:
                incident.description += f" Evidence snapshot saved: {path}"
                db.commit()

        # Notification Service: persist an in-app notification for every proctor/admin,
        # plus a best-effort email alert.
        proctors = db.query(models.User).filter(
            models.User.role.in_([models.RoleEnum.proctor, models.RoleEnum.admin]),
            models.User.is_active == True,  # noqa: E712
        ).all()
        for p in proctors:
            db.add(models.Notification(
                user_id=p.id, title=f"Incident: {incident.title}",
                message=incident.description, severity=incident.severity,
            ))
            send_email_alert(p.email, f"[Exam Integrity] {incident.title}", incident.description)
        db.commit()

    await manager.broadcast(session.exam_id, {
        "type": "incident" if incident else "event",
        "session_id": session.id,
        "student_id": session.student_id,
        "channel": channel,
        "event_type": event.event_type,
        "severity": event.severity,
        "reasons": event.reasons,
        "integrity_score": session.integrity_score,
        "risk_level": session.risk_level.value,
        "incident_id": incident.id if incident else None,
    })
    return event


def _clear_event(session_id: int, channel: str) -> schemas.MonitoringEventOut:
    return schemas.MonitoringEventOut(
        id=0, session_id=session_id, channel=channel, event_type="clear",
        severity="low", confidence=1.0, details={}, reasons=[], score_impact=0.0,
        timestamp=utcnow(),
    )


# ---------------- Video channel (REAL face detection + heuristic gaze/phone) ----------------

@router.post("/{session_id}/webcam-frame", response_model=List[schemas.MonitoringEventOut])
async def ingest_webcam_frame(
    session_id: int,
    payload: schemas.WebcamFrameIn,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    session = _get_session_or_404(session_id, db, user)
    result = video_analysis.analyze_frame(payload.image_base64)

    if result.get("error"):
        raise HTTPException(400, "Could not decode image")

    if not result["findings"]:
        return [_clear_event(session_id, "video")]

    events = []
    for finding in result["findings"]:
        events.append(await _apply_finding(db, session, "video", finding, raw_frame_b64=payload.image_base64))
    return events


# ---------------- Audio channel (SIMULATED heuristic) ----------------

@router.post("/{session_id}/audio-level", response_model=List[schemas.MonitoringEventOut])
async def ingest_audio_level(
    session_id: int,
    payload: schemas.AudioLevelIn,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    session = _get_session_or_404(session_id, db, user)
    result = audio_heuristic.analyze_audio_sample(
        payload.amplitude, payload.sustained_seconds, payload.voice_count_estimate
    )

    if not result["findings"]:
        return [_clear_event(session_id, "audio")]

    return [await _apply_finding(db, session, "audio", f) for f in result["findings"]]


# ---------------- Screen channel (REAL browser events + SIMULATED heuristic) ----------------

@router.post("/{session_id}/browser-event", response_model=schemas.MonitoringEventOut)
async def ingest_browser_event(
    session_id: int,
    payload: schemas.BrowserEventIn,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    session = _get_session_or_404(session_id, db, user)
    if not browser_events.is_valid_event(payload.event_type):
        raise HTTPException(400, f"Unknown browser event type: {payload.event_type}")

    finding = {"event": payload.event_type, "confidence": 1.0, "details": payload.details}
    return await _apply_finding(db, session, "screen", finding)


@router.post("/{session_id}/screen-metadata", response_model=List[schemas.MonitoringEventOut])
async def ingest_screen_metadata(
    session_id: int,
    payload: schemas.ScreenMetadataIn,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    session = _get_session_or_404(session_id, db, user)
    result = screen_heuristic.analyze_screen_metadata(payload.active_window_titles, payload.monitor_count)

    if not result["findings"]:
        return [_clear_event(session_id, "screen")]

    return [await _apply_finding(db, session, "screen", f) for f in result["findings"]]


# ---------------- Behavior channel (REAL heuristics on activity timestamps) ----------------

@router.post("/{session_id}/heartbeat", response_model=List[schemas.MonitoringEventOut])
async def ingest_heartbeat(
    session_id: int,
    payload: schemas.HeartbeatIn,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.get_current_user),
):
    session = _get_session_or_404(session_id, db, user)
    result = behavior_heuristic.check_idle(session.last_activity_at)

    if not result["findings"]:
        session.last_activity_at = utcnow()
        db.commit()
        return [_clear_event(session_id, "behavior")]

    return [await _apply_finding(db, session, "behavior", f) for f in result["findings"]]


# ---------------- Event history ----------------

@router.get("/{session_id}/events", response_model=List[schemas.MonitoringEventOut])
def list_events(session_id: int, db: Session = Depends(get_db), user: models.User = Depends(auth.get_current_user)):
    session = _get_session_or_404(session_id, db, user)
    return (
        db.query(models.MonitoringEvent)
        .filter(models.MonitoringEvent.session_id == session.id)
        .order_by(models.MonitoringEvent.timestamp.desc())
        .all()
    )
