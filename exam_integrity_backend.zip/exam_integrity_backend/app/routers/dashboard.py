from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from sqlalchemy.orm import Session

from app import models, schemas, auth
from app.database import get_db, SessionLocal
from app.websocket_manager import manager

router = APIRouter(tags=["dashboard"])


@router.get("/dashboard/exam/{exam_id}/summary", response_model=schemas.ExamSummaryOut)
def exam_summary(
    exam_id: int,
    db: Session = Depends(get_db),
    user: models.User = Depends(auth.require_role(models.RoleEnum.proctor, models.RoleEnum.admin)),
):
    exam = db.query(models.Exam).filter(models.Exam.id == exam_id).first()
    if not exam:
        raise HTTPException(404, "Exam not found")

    sessions = db.query(models.ExamSession).filter(models.ExamSession.exam_id == exam_id).all()
    active = [s for s in sessions if s.status == models.SessionStatus.in_progress]
    avg_score = sum(s.integrity_score for s in sessions) / len(sessions) if sessions else 100.0

    breakdown = {"low": 0, "medium": 0, "high": 0, "critical": 0}
    for s in sessions:
        breakdown[s.risk_level.value] += 1

    open_incidents = (
        db.query(models.Incident)
        .join(models.ExamSession, models.ExamSession.id == models.Incident.session_id)
        .filter(models.ExamSession.exam_id == exam_id, models.Incident.resolved == False)  # noqa: E712
        .count()
    )

    return schemas.ExamSummaryOut(
        exam_id=exam_id,
        total_sessions=len(sessions),
        active_sessions=len(active),
        average_integrity_score=round(avg_score, 2),
        risk_breakdown=breakdown,
        open_incidents=open_incidents,
    )


@router.websocket("/ws/proctor/{exam_id}")
async def proctor_alerts_ws(websocket: WebSocket, exam_id: int):
    """
    Live feed of monitoring events / incidents for an exam. A proctor
    dashboard opens this socket and receives a JSON message every time
    any student's channel produces a flagged event.

    Auth note: for simplicity this demo expects a `token` query param
    (?token=<JWT>) rather than an Authorization header, since browsers
    cannot set custom headers on WebSocket upgrade requests.
    """
    token = websocket.query_params.get("token")
    db = SessionLocal()
    try:
        if not token:
            await websocket.close(code=4401)
            return
        try:
            from jose import jwt
            from app.config import settings

            payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
            user = db.query(models.User).filter(models.User.id == int(payload.get("sub"))).first()
            if not user or user.role not in (models.RoleEnum.proctor, models.RoleEnum.admin):
                await websocket.close(code=4403)
                return
        except Exception:
            await websocket.close(code=4401)
            return

        await manager.connect(exam_id, websocket)
        try:
            while True:
                # We don't expect inbound messages, but must keep the loop
                # alive to detect disconnects.
                await websocket.receive_text()
        except WebSocketDisconnect:
            manager.disconnect(exam_id, websocket)
    finally:
        db.close()
