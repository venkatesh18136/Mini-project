import os
from dotenv import load_dotenv

load_dotenv()


class Settings:
    SECRET_KEY: str = os.getenv("SECRET_KEY", "dev-only-secret-change-me")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 8  # 8 hours

    # DATA STORAGE — defaults to SQLite for zero-config local testing.
    # For the MySQL setup shown in the architecture diagram, set e.g.:
    #   DATABASE_URL=mysql+pymysql://user:password@localhost:3306/exam_integrity
    # and `pip install pymysql cryptography`.
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./exam_integrity.db")

    # Risk engine thresholds (integrity score starts at 100 and decays with events)
    RISK_LOW_MIN: float = 85.0
    RISK_MEDIUM_MIN: float = 70.0
    RISK_HIGH_MIN: float = 50.0
    # below RISK_HIGH_MIN => critical

    # Temporal analysis (Evidence Fusion & Risk Scoring Pipeline)
    TEMPORAL_WINDOW_SECONDS: int = 120       # look-back window for repeat/correlation checks
    REPEAT_ESCALATION_COUNT: int = 3         # same event N+ times in window => escalate
    CROSS_CHANNEL_ESCALATION_COUNT: int = 3  # N+ high/critical events across channels in window => abnormal pattern

    # Behavior channel thresholds
    IDLE_SECONDS_THRESHOLD: int = 180        # no activity for this long => idle_time_exceeded
    RAPID_ANSWER_SECONDS_THRESHOLD: float = 3.0  # answer submitted faster than this => suspicious

    # Evidence storage (local-disk stand-in for the "Cloud Storage" integration in the diagram)
    EVIDENCE_STORAGE_DIR: str = os.getenv("EVIDENCE_STORAGE_DIR", "./evidence")
    SAVE_EVIDENCE_SNAPSHOTS: bool = os.getenv("SAVE_EVIDENCE_SNAPSHOTS", "true").lower() == "true"

    # Notification Service — email alerts are best-effort and silently skipped
    # unless SMTP settings are provided (keeps the project runnable with zero config).
    SMTP_HOST: str = os.getenv("SMTP_HOST", "")
    SMTP_PORT: int = int(os.getenv("SMTP_PORT", "587"))
    SMTP_USERNAME: str = os.getenv("SMTP_USERNAME", "")
    SMTP_PASSWORD: str = os.getenv("SMTP_PASSWORD", "")
    SMTP_FROM_ADDRESS: str = os.getenv("SMTP_FROM_ADDRESS", "no-reply@exam-integrity.local")
    EMAIL_ALERTS_ENABLED: bool = bool(os.getenv("SMTP_HOST"))


settings = Settings()
