import datetime
from typing import Optional, List, Dict, Any

from pydantic import BaseModel, EmailStr, ConfigDict

from app.models import RoleEnum, SessionStatus, RiskLevel, ReviewDecision


# ---------- Auth / Users ----------

class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: RoleEnum = RoleEnum.student


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    email: EmailStr
    role: RoleEnum
    is_active: bool
    created_at: datetime.datetime


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ---------- Exams / Questions ----------

class ExamCreate(BaseModel):
    title: str
    description: str = ""
    duration_minutes: int = 60
    plagiarism_threshold: float = 0.80


class ExamUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    duration_minutes: Optional[int] = None
    plagiarism_threshold: Optional[float] = None


class ExamOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    description: str
    duration_minutes: int
    plagiarism_threshold: float
    created_at: datetime.datetime


class EnrollRequest(BaseModel):
    student_ids: List[int]


class QuestionCreate(BaseModel):
    question_text: str
    question_order: int = 1
    max_marks: float = 1.0


class QuestionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    exam_id: int
    question_text: str
    question_order: int
    max_marks: float


# ---------- Sessions ----------

class SessionStartRequest(BaseModel):
    exam_id: int


class SessionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    exam_id: int
    student_id: int
    status: SessionStatus
    integrity_score: float
    risk_level: RiskLevel
    start_time: Optional[datetime.datetime]
    end_time: Optional[datetime.datetime]
    last_activity_at: Optional[datetime.datetime]


# ---------- Monitoring (Data Collection channels) ----------

class WebcamFrameIn(BaseModel):
    image_base64: str


class AudioLevelIn(BaseModel):
    amplitude: float                  # 0-100 client-side volume meter reading
    sustained_seconds: float = 0.0
    voice_count_estimate: Optional[int] = None  # optional client-side hint for multi-voice detection


class BrowserEventIn(BaseModel):
    event_type: str           # tab_switch | window_blur | copy_detected | paste_detected |
                               # devtools_opened | fullscreen_exit | right_click_attempt
    details: Dict[str, Any] = {}


class ScreenMetadataIn(BaseModel):
    active_window_titles: List[str] = []
    monitor_count: int = 1


class HeartbeatIn(BaseModel):
    """Behavior channel — periodic client ping used for idle-time detection."""
    client_timestamp: Optional[datetime.datetime] = None


class MonitoringEventOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    session_id: int
    channel: str
    event_type: str
    severity: str
    confidence: float
    details: Dict[str, Any]
    reasons: List[str] = []
    score_impact: float
    timestamp: datetime.datetime


# ---------- Incidents ----------

class IncidentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    session_id: int
    title: str
    description: str
    channel: str
    severity: str
    reasons: List[str] = []
    resolved: bool
    created_at: datetime.datetime


# ---------- Answers / Plagiarism ----------

class AnswerIn(BaseModel):
    question_id: str
    answer_text: str


class PlagiarismReportOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    exam_id: int
    question_id: str
    student_a_id: int
    student_b_id: int
    similarity_score: float
    flagged: bool
    created_at: datetime.datetime


# ---------- Human Review & Decision ----------

class ReviewIn(BaseModel):
    decision: ReviewDecision
    comments: str = ""


class ReviewOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    session_id: int
    reviewer_id: int
    decision: ReviewDecision
    comments: str
    created_at: datetime.datetime
    updated_at: datetime.datetime


# ---------- Dashboard / Reports ----------

class ExamSummaryOut(BaseModel):
    exam_id: int
    total_sessions: int
    active_sessions: int
    average_integrity_score: float
    risk_breakdown: Dict[str, int]
    open_incidents: int


class RiskTrendPointOut(BaseModel):
    timestamp: datetime.datetime
    score: float
    risk_level: str


class SessionReportOut(BaseModel):
    session: SessionOut
    student: UserOut
    events: List[MonitoringEventOut]
    incidents: List[IncidentOut]
    risk_trend: List[RiskTrendPointOut]
    review: Optional[ReviewOut] = None
    plagiarism_matches: List[PlagiarismReportOut] = []


# ---------- Notifications ----------

class NotificationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    message: str
    severity: str
    read: bool
    created_at: datetime.datetime


# ---------- Admin ----------

class AuditLogOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    actor_id: int
    action: str
    target_type: str
    target_id: Optional[int]
    details: Dict[str, Any]
    created_at: datetime.datetime


class SystemSettingIn(BaseModel):
    value: str


class SystemSettingOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    key: str
    value: str
    updated_at: datetime.datetime
