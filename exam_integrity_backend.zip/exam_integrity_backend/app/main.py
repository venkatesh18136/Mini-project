from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine
from app.routers import (
    auth_routes, exams, sessions, monitoring, incidents, plagiarism,
    dashboard, reviews, reports, admin_routes, notifications,
)

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI-Powered Multi-Channel Exam Integrity and Malpractice Detection System",
    description=(
        "Backend implementing the full multi-channel proctoring architecture: "
        "Client Layer -> Data Collection (video/audio/screen/behavior) -> "
        "AI Detection Engine -> Backend Services (FastAPI) -> Evidence Fusion "
        "& Risk Scoring Pipeline -> Dashboard & Review Layer -> Data Storage. "
        "Video face-detection and TF-IDF plagiarism checks are real; audio, "
        "screen-process, and object/gaze detection are lightweight heuristics "
        "documented as extension points for production ML models."
    ),
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_routes.router)
app.include_router(exams.router)
app.include_router(sessions.router)
app.include_router(monitoring.router)
app.include_router(incidents.router)
app.include_router(plagiarism.router)
app.include_router(reviews.router)
app.include_router(dashboard.router)
app.include_router(reports.router)
app.include_router(notifications.router)
app.include_router(admin_routes.router)


@app.get("/", tags=["health"])
def health_check():
    return {"status": "ok", "service": "exam-integrity-backend"}
