from typing import Dict, List

from fastapi import WebSocket


class ConnectionManager:
    """Tracks proctor dashboards subscribed to live alerts for a given exam."""

    def __init__(self) -> None:
        self.active: Dict[int, List[WebSocket]] = {}

    async def connect(self, exam_id: int, websocket: WebSocket) -> None:
        await websocket.accept()
        self.active.setdefault(exam_id, []).append(websocket)

    def disconnect(self, exam_id: int, websocket: WebSocket) -> None:
        if exam_id in self.active and websocket in self.active[exam_id]:
            self.active[exam_id].remove(websocket)

    async def broadcast(self, exam_id: int, message: dict) -> None:
        for ws in list(self.active.get(exam_id, [])):
            try:
                await ws.send_json(message)
            except Exception:
                self.disconnect(exam_id, ws)


manager = ConnectionManager()
