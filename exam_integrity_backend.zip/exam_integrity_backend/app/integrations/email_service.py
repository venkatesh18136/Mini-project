"""
Notification Service — external integration: Email Service (SMTP).

Best-effort and non-blocking: if SMTP_HOST isn't configured, this is a
no-op so the project runs with zero external config. When configured, it
sends a plain-text alert email. Any failure is caught and logged, never
raised, so a flaky mail server can't break exam monitoring.
"""
import smtplib
import ssl
from email.message import EmailMessage

from app.config import settings


def send_email_alert(to_email: str, subject: str, body: str) -> bool:
    if not settings.EMAIL_ALERTS_ENABLED:
        return False

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = settings.SMTP_FROM_ADDRESS
    msg["To"] = to_email
    msg.set_content(body)

    try:
        context = ssl.create_default_context()
        with smtplib.SMTP(settings.SMTP_HOST, settings.SMTP_PORT, timeout=5) as server:
            server.starttls(context=context)
            if settings.SMTP_USERNAME:
                server.login(settings.SMTP_USERNAME, settings.SMTP_PASSWORD)
            server.send_message(msg)
        return True
    except Exception:
        # Deliberately swallow errors — email delivery must never break the monitoring flow.
        return False
