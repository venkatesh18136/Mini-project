"""
External integration: Cloud Storage (For Evidence).

For this project, evidence snapshots (webcam frames captured at the
moment of a high/critical incident) are saved to local disk under
EVIDENCE_STORAGE_DIR. The function signature is deliberately storage-
agnostic — swap the body for an S3 `put_object` call (or similar) to move
to real cloud storage without touching any calling code.
"""
import base64
import os
import uuid
from typing import Optional

from app.config import settings


def save_evidence_snapshot(session_id: int, image_base64: str) -> Optional[str]:
    if not settings.SAVE_EVIDENCE_SNAPSHOTS:
        return None

    try:
        if "," in image_base64:
            image_base64 = image_base64.split(",", 1)[1]
        img_bytes = base64.b64decode(image_base64)
    except Exception:
        return None

    session_dir = os.path.join(settings.EVIDENCE_STORAGE_DIR, str(session_id))
    os.makedirs(session_dir, exist_ok=True)

    filename = f"{uuid.uuid4().hex}.jpg"
    path = os.path.join(session_dir, filename)
    try:
        with open(path, "wb") as f:
            f.write(img_bytes)
        return path
    except Exception:
        return None
