"""
Automated feature checklist for the Exam Integrity backend.

Run with:
    pytest tests/test_all_features.py -v

Each test name maps to one feature from the architecture diagram, so a
passing run is a feature-by-feature confirmation that the system works
end to end. This uses a throwaway SQLite file (test_exam_integrity.db)
that is deleted before and after the run — it never touches your real
exam_integrity.db.
"""
import base64
import os
import time

import cv2
import numpy as np
import pytest

os.environ["DATABASE_URL"] = "sqlite:///./test_exam_integrity.db"
os.environ["EVIDENCE_STORAGE_DIR"] = "./test_evidence"

if os.path.exists("./test_exam_integrity.db"):
    os.remove("./test_exam_integrity.db")

from fastapi.testclient import TestClient  # noqa: E402
from app.main import app  # noqa: E402

client = TestClient(app)


def _login(email, password="pass123"):
    r = client.post("/auth/login", data={"username": email, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def _register(name, email, role, password="pass123"):
    r = client.post("/auth/register", json={"name": name, "email": email, "password": password, "role": role})
    assert r.status_code == 201, r.text
    return r.json()["id"]


def _b64_jpeg(np_image):
    _, buf = cv2.imencode(".jpg", np_image)
    return base64.b64encode(buf).decode()


@pytest.fixture(scope="module")
def world():
    """One shared exam/session/users setup reused across feature tests."""
    admin_id = _register("Admin", "admin@example.com", "admin")
    proctor_id = _register("Proctor", "proctor@example.com", "proctor")
    student_id = _register("Student", "student@example.com", "student")

    admin_h = _login("admin@example.com")
    proctor_h = _login("proctor@example.com")
    student_h = _login("student@example.com")

    r = client.post("/exams", json={"title": "Feature Test Exam", "plagiarism_threshold": 0.8}, headers=proctor_h)
    exam_id = r.json()["id"]
    client.post(f"/exams/{exam_id}/questions", json={"question_text": "Explain normalization.", "question_order": 1}, headers=proctor_h)
    client.post(f"/exams/{exam_id}/enroll", json={"student_ids": [student_id]}, headers=proctor_h)

    r = client.post("/sessions/start", json={"exam_id": exam_id}, headers=student_h)
    session_id = r.json()["id"]

    return {
        "admin_h": admin_h, "proctor_h": proctor_h, "student_h": student_h,
        "admin_id": admin_id, "proctor_id": proctor_id, "student_id": student_id,
        "exam_id": exam_id, "session_id": session_id,
    }


# ---------------------------------------------------------------- Auth ----

def test_auth_register_login_me(world):
    r = client.get("/auth/me", headers=world["student_h"])
    assert r.status_code == 200
    assert r.json()["role"] == "student"


def test_auth_rejects_duplicate_email():
    _register("Dup", "dup@example.com", "student")
    r = client.post("/auth/register", json={"name": "Dup2", "email": "dup@example.com", "password": "pass123", "role": "student"})
    assert r.status_code == 400


def test_auth_rejects_wrong_password():
    r = client.post("/auth/login", data={"username": "dup@example.com", "password": "wrong"})
    assert r.status_code == 401


def test_auth_rejects_missing_token():
    r = client.get("/exams")
    assert r.status_code == 401


# --------------------------------------------------------- Exam Service ----

def test_exam_create_and_list(world):
    r = client.get("/exams", headers=world["proctor_h"])
    assert r.status_code == 200
    assert any(e["id"] == world["exam_id"] for e in r.json())


def test_exam_update(world):
    r = client.patch(f"/exams/{world['exam_id']}", json={"description": "updated"}, headers=world["proctor_h"])
    assert r.status_code == 200 and r.json()["description"] == "updated"


def test_exam_question_bank(world):
    r = client.get(f"/exams/{world['exam_id']}/questions", headers=world["proctor_h"])
    assert r.status_code == 200 and len(r.json()) >= 1


def test_exam_student_only_role_blocked_from_creating_exam(world):
    r = client.post("/exams", json={"title": "nope"}, headers=world["student_h"])
    assert r.status_code == 403


# ----------------------------------------------------- Session Service ----

def test_session_lifecycle(world):
    r = client.get(f"/sessions/{world['session_id']}", headers=world["student_h"])
    assert r.status_code == 200
    assert r.json()["status"] == "in_progress"
    assert r.json()["integrity_score"] == 100.0


# ------------------------------------------------- Video channel (REAL) ----

def test_video_channel_camera_obstructed(world):
    dark = np.zeros((200, 200, 3), dtype=np.uint8)
    r = client.post(f"/monitoring/{world['session_id']}/webcam-frame",
                     json={"image_base64": _b64_jpeg(dark)}, headers=world["student_h"])
    assert r.status_code == 200
    assert r.json()[0]["event_type"] == "camera_obstructed"


def test_video_channel_no_face_detected(world):
    bright = np.full((300, 300, 3), 200, dtype=np.uint8)
    r = client.post(f"/monitoring/{world['session_id']}/webcam-frame",
                     json={"image_base64": _b64_jpeg(bright)}, headers=world["student_h"])
    assert r.status_code == 200
    assert r.json()[0]["event_type"] == "no_face_detected"


# ------------------------------------------------- Audio channel (SIM) ----

def test_audio_channel_spike_and_multivoice(world):
    r = client.post(f"/monitoring/{world['session_id']}/audio-level",
                     json={"amplitude": 90, "sustained_seconds": 1, "voice_count_estimate": 2},
                     headers=world["student_h"])
    assert r.status_code == 200
    types = {e["event_type"] for e in r.json()}
    assert "audio_spike_detected" in types and "multiple_voice_detected" in types


# --------------------------------------------- Screen channel (REAL+SIM) ----

def test_screen_channel_browser_event_opens_critical_incident(world):
    r = client.post(f"/monitoring/{world['session_id']}/browser-event",
                     json={"event_type": "devtools_opened"}, headers=world["student_h"])
    assert r.status_code == 200
    assert r.json()["severity"] == "critical"

    incidents = client.get(f"/exams/{world['exam_id']}/incidents", headers=world["proctor_h"]).json()
    assert any(i["severity"] == "critical" for i in incidents)


def test_screen_channel_blocklist_and_monitor_heuristic(world):
    r = client.post(f"/monitoring/{world['session_id']}/screen-metadata",
                     json={"active_window_titles": ["WhatsApp Web"], "monitor_count": 2},
                     headers=world["student_h"])
    assert r.status_code == 200
    types = {e["event_type"] for e in r.json()}
    assert "prohibited_application_detected" in types
    assert "multiple_monitors_suspected" in types


def test_screen_channel_rejects_unknown_event_type(world):
    r = client.post(f"/monitoring/{world['session_id']}/browser-event",
                     json={"event_type": "totally_made_up"}, headers=world["student_h"])
    assert r.status_code == 400


# --------------------------------------------- Behavior channel (REAL) ----

def test_behavior_heartbeat_clear_when_active(world):
    r = client.post(f"/monitoring/{world['session_id']}/heartbeat", json={}, headers=world["student_h"])
    assert r.status_code == 200
    assert r.json()[0]["event_type"] == "clear"


def test_behavior_backtracking_and_rapid_answering(world):
    client.post(f"/sessions/{world['session_id']}/answers",
                json={"question_id": "Q1", "answer_text": "First answer."}, headers=world["student_h"])
    r = client.post(f"/sessions/{world['session_id']}/answers",
                     json={"question_id": "Q1", "answer_text": "Edited answer."}, headers=world["student_h"])
    assert r.json()["is_edit"] is True

    events = client.get(f"/monitoring/{world['session_id']}/events", headers=world["student_h"]).json()
    behavior_types = {e["event_type"] for e in events if e["channel"] == "behavior"}
    assert "backtracking_detected" in behavior_types
    assert "rapid_answering_detected" in behavior_types


# ------------------------------------- Evidence Fusion & Risk Pipeline ----

def test_temporal_analysis_escalates_repeats(world):
    for _ in range(3):
        client.post(f"/monitoring/{world['session_id']}/browser-event",
                     json={"event_type": "tab_switch"}, headers=world["student_h"])
    events = client.get(f"/monitoring/{world['session_id']}/events", headers=world["student_h"]).json()
    tab_events = [e for e in events if e["event_type"] == "tab_switch"]
    assert any("escalated" in r for e in tab_events for r in e["reasons"])


def test_evidence_fusion_flags_abnormal_pattern(world):
    # already have 2 high/critical events (devtools_opened, prohibited_application_detected)
    # from earlier tests in this module — one more screen high-severity event should trigger fusion
    client.post(f"/monitoring/{world['session_id']}/screen-metadata",
                json={"active_window_titles": ["AnyDesk"], "monitor_count": 1}, headers=world["student_h"])
    events = client.get(f"/monitoring/{world['session_id']}/events", headers=world["student_h"]).json()
    assert any(e["event_type"] == "abnormal_pattern_detected" for e in events)


def test_risk_score_decayed_and_risk_level_updated(world):
    r = client.get(f"/sessions/{world['session_id']}", headers=world["student_h"])
    assert r.json()["integrity_score"] < 100.0
    assert r.json()["risk_level"] in ("medium", "high", "critical")


# ------------------------------------------------------- Plagiarism ----

def test_plagiarism_check(world):
    r2 = client.post("/auth/register", json={"name": "S2", "email": "s2@example.com", "password": "pass123", "role": "student"})
    s2_id = r2.json()["id"]
    client.post(f"/exams/{world['exam_id']}/enroll", json={"student_ids": [s2_id]}, headers=world["proctor_h"])
    s2_h = _login("s2@example.com")
    r = client.post("/sessions/start", json={"exam_id": world["exam_id"]}, headers=s2_h)
    s2_session = r.json()["id"]

    client.post(f"/sessions/{s2_session}/answers",
                json={"question_id": "Q1", "answer_text": "First answer."}, headers=s2_h)  # near-identical to student1's first answer

    r = client.post(f"/exams/{world['exam_id']}/plagiarism-check", headers=world["proctor_h"])
    assert r.status_code == 200
    assert len(r.json()) >= 1


# --------------------------------------------------- Human Review ----

def test_human_review_submit_and_get(world):
    r = client.put(f"/sessions/{world['session_id']}/review",
                    json={"decision": "suspicious", "comments": "Multiple flags."}, headers=world["proctor_h"])
    assert r.status_code == 200 and r.json()["decision"] == "suspicious"

    r = client.get(f"/sessions/{world['session_id']}/review", headers=world["proctor_h"])
    assert r.status_code == 200


# --------------------------------------------------- Notifications ----

def test_notifications_created_for_proctor(world):
    r = client.get("/notifications", headers=world["proctor_h"])
    assert r.status_code == 200 and len(r.json()) >= 1

    notif_id = r.json()[0]["id"]
    r2 = client.patch(f"/notifications/{notif_id}/read", headers=world["proctor_h"])
    assert r2.status_code == 200 and r2.json()["read"] is True


# --------------------------------------------------- Reports ----

def test_report_session_json(world):
    r = client.get(f"/reports/session/{world['session_id']}", headers=world["proctor_h"])
    assert r.status_code == 200
    body = r.json()
    assert body["session"]["id"] == world["session_id"]
    assert len(body["events"]) > 0
    assert len(body["risk_trend"]) > 0


def test_report_session_pdf(world):
    r = client.get(f"/reports/session/{world['session_id']}/pdf", headers=world["proctor_h"])
    assert r.status_code == 200
    assert r.headers["content-type"] == "application/pdf"
    assert len(r.content) > 500


def test_report_exam_csv(world):
    r = client.get(f"/reports/exam/{world['exam_id']}/csv", headers=world["proctor_h"])
    assert r.status_code == 200
    assert "session_id" in r.text


def test_report_risk_trend(world):
    r = client.get(f"/reports/session/{world['session_id']}/risk-trend", headers=world["proctor_h"])
    assert r.status_code == 200 and len(r.json()) > 0


# --------------------------------------------------- Incidents ----

def test_incident_resolve(world):
    incidents = client.get(f"/exams/{world['exam_id']}/incidents", headers=world["proctor_h"]).json()
    assert len(incidents) > 0
    inc_id = incidents[0]["id"]
    r = client.patch(f"/incidents/{inc_id}/resolve", headers=world["proctor_h"])
    assert r.status_code == 200 and r.json()["resolved"] is True


# --------------------------------------------------- Admin ----

def test_admin_user_management(world):
    r = client.get("/admin/users", headers=world["admin_h"])
    assert r.status_code == 200 and len(r.json()) >= 3

    r = client.patch(f"/admin/users/{world['student_id']}/deactivate", headers=world["admin_h"])
    assert r.status_code == 200 and r.json()["is_active"] is False

    # deactivated user can still get a token, but every authenticated call is blocked
    h = _login("student@example.com")
    r = client.get("/auth/me", headers=h)
    assert r.status_code == 403

    client.patch(f"/admin/users/{world['student_id']}/activate", headers=world["admin_h"])


def test_admin_audit_log_records_actions(world):
    r = client.get("/admin/audit-logs", headers=world["admin_h"])
    assert r.status_code == 200 and len(r.json()) > 0


def test_admin_system_settings(world):
    r = client.put("/admin/settings/demo_key", json={"value": "42"}, headers=world["admin_h"])
    assert r.status_code == 200
    r = client.get("/admin/settings", headers=world["admin_h"])
    assert any(s["key"] == "demo_key" and s["value"] == "42" for s in r.json())


def test_admin_routes_blocked_for_proctor(world):
    r = client.get("/admin/users", headers=world["proctor_h"])
    assert r.status_code == 403


# --------------------------------------------------- Dashboard / WS ----

def test_dashboard_summary(world):
    r = client.get(f"/dashboard/exam/{world['exam_id']}/summary", headers=world["proctor_h"])
    assert r.status_code == 200
    assert r.json()["total_sessions"] >= 1


def test_websocket_live_alert_push(world):
    token = world["proctor_h"]["Authorization"].split(" ")[1]
    with client.websocket_connect(f"/ws/proctor/{world['exam_id']}?token={token}") as ws:
        client.post(f"/monitoring/{world['session_id']}/browser-event",
                     json={"event_type": "window_blur"}, headers=world["student_h"])
        msg = ws.receive_json()
        assert msg["channel"] == "screen"
        assert msg["event_type"] == "window_blur"


def test_websocket_rejects_unauthenticated(world):
    with pytest.raises(Exception):
        with client.websocket_connect(f"/ws/proctor/{world['exam_id']}"):
            pass


# ------------------------------------------------ Evidence storage ----

def test_evidence_snapshot_saved_on_high_severity_video_event(world):
    # multiple_faces_detected (high severity) can't be reliably staged without
    # a real two-face photo, so this exercises the storage function directly —
    # the same function the monitoring router calls on qualifying incidents.
    from app.integrations.storage_service import save_evidence_snapshot
    dark = np.zeros((100, 100, 3), dtype=np.uint8)
    path = save_evidence_snapshot(world["session_id"], _b64_jpeg(dark))
    assert path is not None and os.path.exists(path)
