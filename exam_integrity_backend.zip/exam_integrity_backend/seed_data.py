"""
Optional convenience script: creates a demo proctor, two demo students,
and a demo exam with both students enrolled, so you can immediately
explore the API via /docs without registering everything by hand.

Run with:  python seed_data.py
"""
from app.database import Base, engine, SessionLocal
from app import models, auth

Base.metadata.create_all(bind=engine)
db = SessionLocal()

DEMO_USERS = [
    ("Admin User", "admin@demo.com", "admin123", models.RoleEnum.admin),
    ("Prof. Sharma", "proctor@demo.com", "proctor123", models.RoleEnum.proctor),
    ("Alice", "alice@demo.com", "student123", models.RoleEnum.student),
    ("Bob", "bob@demo.com", "student123", models.RoleEnum.student),
]

created_users = {}
for name, email, password, role in DEMO_USERS:
    existing = db.query(models.User).filter(models.User.email == email).first()
    if existing:
        created_users[email] = existing
        continue
    user = models.User(name=name, email=email, hashed_password=auth.hash_password(password), role=role)
    db.add(user)
    db.commit()
    db.refresh(user)
    created_users[email] = user
    print(f"Created {role.value}: {email} / {password}")

proctor = created_users["proctor@demo.com"]
alice = created_users["alice@demo.com"]
bob = created_users["bob@demo.com"]

exam = db.query(models.Exam).filter(models.Exam.title == "Demo Data Structures Exam").first()
if not exam:
    exam = models.Exam(
        title="Demo Data Structures Exam",
        description="Auto-created demo exam for testing the integrity system.",
        duration_minutes=60,
        plagiarism_threshold=0.8,
        created_by=proctor.id,
    )
    db.add(exam)
    db.commit()
    db.refresh(exam)
    print(f"Created exam id={exam.id}: {exam.title}")

for student in (alice, bob):
    exists = (
        db.query(models.ExamEnrollment)
        .filter(models.ExamEnrollment.exam_id == exam.id, models.ExamEnrollment.student_id == student.id)
        .first()
    )
    if not exists:
        db.add(models.ExamEnrollment(exam_id=exam.id, student_id=student.id))

if db.query(models.Question).filter(models.Question.exam_id == exam.id).count() == 0:
    db.add_all([
        models.Question(exam_id=exam.id, question_text="What is database normalization?", question_order=1),
        models.Question(exam_id=exam.id, question_text="Explain the ACID properties.", question_order=2),
    ])

db.commit()
exam_id = exam.id  # capture before closing the session
db.close()

print("\nSeed complete. Demo credentials:")
print("  Admin   : admin@demo.com   / admin123")
print("  Proctor : proctor@demo.com / proctor123")
print("  Student : alice@demo.com   / student123")
print("  Student : bob@demo.com     / student123")
print(f"  Exam ID : {exam_id}")
