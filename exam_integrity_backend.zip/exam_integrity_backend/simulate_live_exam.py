"""
simulate_live_exam.py — a realistic end-to-end walkthrough.

Simulates what actually happens while a proctor is examining a student
writing an exam: the proctor's dashboard is connected to the live
WebSocket feed, and the student's browser is sending webcam/audio/screen/
behavior data over the course of the exam — including a deliberate
"gets suspicious" turn midway through — so you can watch every channel,
the risk-score decay, incident creation, and the final human review
happen in the order they actually would in production.

USAGE (two terminals):
    Terminal 1:  uvicorn app.main:app --reload
    Terminal 2:  pip install -r requirements-dev.txt   # httpx, if not already installed
                 python simulate_live_exam.py

Everything is printed with a timestamp and an actor label (SYSTEM /
STUDENT / PROCTOR) so the transcript itself reads like an incident log.
"""
import asyncio
import base64
import json
import time
from datetime import datetime

import cv2
import numpy as np
import httpx
import websockets

BASE_URL = "http://127.0.0.1:8000"
WS_URL = "ws://127.0.0.1:8000"


def jpeg_b64(img: np.ndarray) -> str:
    _, buf = cv2.imencode(".jpg", img)
    return base64.b64encode(buf).decode()


def log(actor: str, msg: str) -> None:
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"[{ts}] {actor:9s} | {msg}")


def register_or_login(client: httpx.Client, name: str, email: str, role: str, password: str = "pass123") -> str:
    r = client.post("/auth/register", json={"name": name, "email": email, "password": password, "role": role})
    if r.status_code not in (201, 400):
        raise RuntimeError(f"register failed: {r.status_code} {r.text}")
    r = client.post("/auth/login", data={"username": email, "password": password})
    r.raise_for_status()
    return r.json()["access_token"]


async def proctor_listener(exam_id: int, token: str, stop_event: asyncio.Event) -> None:
    """Mimics the proctor's live dashboard: prints every alert the instant it arrives."""
    uri = f"{WS_URL}/ws/proctor/{exam_id}?token={token}"
    async with websockets.connect(uri) as ws:
        log("PROCTOR", "connected to live alert feed, watching...")
        while not stop_event.is_set():
            try:
                raw = await asyncio.wait_for(ws.recv(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            msg = json.loads(raw)
            tag = "\U0001F6A8 INCIDENT" if msg["type"] == "incident" else "  event  "
            log("PROCTOR", f"{tag} | {msg['channel']}/{msg['event_type']:28s} "
                            f"severity={msg['severity']:8s} score={msg['integrity_score']:.1f} "
                            f"risk={msg['risk_level']}")


def student_takes_exam(client: httpx.Client, headers: dict, session_id: int) -> None:
    """Mimics ~a minute of real exam-taking behaviour, including a cheating turn."""
    log("STUDENT", "exam window opened, webcam/mic active")

    # --- Normal start: face visible, quiet room, answers Q1 honestly ---
    ok_frame = np.full((300, 300, 3), 220, dtype=np.uint8)
    cv2.rectangle(ok_frame, (110, 90), (190, 190), (150, 150, 150), -1)
    client.post(f"/monitoring/{session_id}/webcam-frame", json={"image_base64": jpeg_b64(ok_frame)}, headers=headers)
    client.post(f"/monitoring/{session_id}/audio-level", json={"amplitude": 12, "sustained_seconds": 0}, headers=headers)
    client.post(f"/monitoring/{session_id}/heartbeat", json={}, headers=headers)
    log("STUDENT", "answering Q1 normally")
    client.post(f"/sessions/{session_id}/answers",
                json={"question_id": "Q1", "answer_text": "Normalization removes redundancy by decomposing tables."},
                headers=headers)
    time.sleep(1.5)

    # --- Suspicious turn starts ---
    log("STUDENT", "*leaves the camera frame*")
    dark_frame = np.zeros((300, 300, 3), dtype=np.uint8)
    client.post(f"/monitoring/{session_id}/webcam-frame", json={"image_base64": jpeg_b64(dark_frame)}, headers=headers)
    time.sleep(1.5)

    log("STUDENT", "*talking to someone off-screen*")
    client.post(f"/monitoring/{session_id}/audio-level",
                json={"amplitude": 92, "sustained_seconds": 4, "voice_count_estimate": 2}, headers=headers)
    time.sleep(1.5)

    log("STUDENT", "*switches tabs 3 times, then opens devtools*")
    for _ in range(3):
        client.post(f"/monitoring/{session_id}/browser-event", json={"event_type": "tab_switch"}, headers=headers)
        time.sleep(0.3)
    client.post(f"/monitoring/{session_id}/browser-event", json={"event_type": "devtools_opened"}, headers=headers)
    time.sleep(1.5)

    log("STUDENT", "*WhatsApp open on a second monitor*")
    client.post(f"/monitoring/{session_id}/screen-metadata",
                json={"active_window_titles": ["WhatsApp Web"], "monitor_count": 2}, headers=headers)
    time.sleep(1.5)

    log("STUDENT", "quickly re-edits the Q1 answer")
    client.post(f"/sessions/{session_id}/answers",
                json={"question_id": "Q1", "answer_text": "Normalization removes redundancy by decomposing tables further."},
                headers=headers)
    time.sleep(1)

    log("STUDENT", "submits and ends the exam")
    client.post(f"/sessions/{session_id}/end", headers=headers)


async def main() -> None:
    with httpx.Client(base_url=BASE_URL, timeout=10) as client:
        # ---- Setup: proctor creates the exam, student is enrolled and starts a session ----
        proctor_token = register_or_login(client, "Prof. Rao", "sim_proctor@example.com", "proctor")
        student_token = register_or_login(client, "Riya", "sim_student@example.com", "student")

        proctor_h = {"Authorization": f"Bearer {proctor_token}"}
        student_h = {"Authorization": f"Bearer {student_token}"}

        r = client.post("/exams", json={"title": "Live Simulation Exam"}, headers=proctor_h)
        exam_id = r.json()["id"]
        client.post(f"/exams/{exam_id}/questions",
                    json={"question_text": "Explain normalization.", "question_order": 1}, headers=proctor_h)

        student_id = client.get("/auth/me", headers=student_h).json()["id"]
        client.post(f"/exams/{exam_id}/enroll", json={"student_ids": [student_id]}, headers=proctor_h)

        r = client.post("/sessions/start", json={"exam_id": exam_id}, headers=student_h)
        session_id = r.json()["id"]
        log("SYSTEM", f"exam_id={exam_id}  session_id={session_id}")

        # ---- Proctor connects to the live feed BEFORE the student starts acting up ----
        stop_event = asyncio.Event()
        listener_task = asyncio.create_task(proctor_listener(exam_id, proctor_token, stop_event))
        await asyncio.sleep(0.5)

        # ---- The exam happens ----
        await asyncio.to_thread(student_takes_exam, client, student_h, session_id)
        await asyncio.sleep(1.5)  # let the last WebSocket messages arrive

        stop_event.set()
        await listener_task

        # ---- Proctor reviews the session after it ends ----
        print()
        log("PROCTOR", "reviewing the session now that it's over...")
        r = client.get(f"/sessions/{session_id}", headers=proctor_h)
        s = r.json()
        log("PROCTOR", f"final integrity_score={s['integrity_score']}  risk_level={s['risk_level']}")

        r = client.get(f"/exams/{exam_id}/incidents", headers=proctor_h)
        log("PROCTOR", f"{len(r.json())} incident(s) recorded:")
        for inc in r.json():
            print(f"      [{inc['severity'].upper():8s}] {inc['title']}")

        r = client.put(f"/sessions/{session_id}/review",
                        json={"decision": "malpractice_confirmed",
                              "comments": "Left camera frame, second device audible, tab switching, devtools opened."},
                        headers=proctor_h)
        log("PROCTOR", f"review submitted: {r.json()['decision']}")

        r = client.get(f"/reports/session/{session_id}/pdf", headers=proctor_h)
        with open("live_simulation_report.pdf", "wb") as f:
            f.write(r.content)
        log("PROCTOR", f"downloaded PDF report ({len(r.content)} bytes) -> live_simulation_report.pdf")


if __name__ == "__main__":
    asyncio.run(main())
