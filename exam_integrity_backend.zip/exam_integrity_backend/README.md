# AI-Powered Multi-Channel Exam Integrity and Malpractice Detection System — Backend

A FastAPI backend implementing the full architecture below: Client Layer →
Data Collection → AI Detection Engine → Backend Services → Evidence Fusion
& Risk Scoring Pipeline → Dashboard & Review Layer → Data Storage.

Built as a minor-project scaffold: fully working end-to-end, but
intentionally lightweight so it runs offline with no GPU, external ML API
keys, or paid services.

## How this maps to the architecture diagram

| Diagram block | Implementation |
|---|---|
| **Client Layer** | Not included (backend-only repo) — see "What's not implemented" below for the frontend contract each client type needs. |
| **Data Collection** (Video/Audio/Screen/Behavior) | `POST /monitoring/{session_id}/...` endpoints — see channel table below. |
| **AI Detection Engine** | `app/detection/` — video (real OpenCV + heuristic gaze/phone), audio (heuristic VAD), screen (heuristic + real event log), behavior (real timestamp-based). |
| **Backend Services (FastAPI)** | `app/routers/` — Auth, Exam, Session, Event (monitoring), AI (detection modules), Risk Engine, Report, Notification services, each as its own router. |
| **Evidence Fusion & Risk Scoring Pipeline** | `app/risk_engine.py` — implements every stage: Preprocessing → Temporal Analysis → Risk Scoring → Risk Level → Explainable Output, plus cross-channel Evidence Fusion. |
| **Data Storage (diagram: MySQL)** | SQLAlchemy ORM in `app/models.py`, defaults to SQLite for zero-config testing, MySQL-ready via `DATABASE_URL`. Tables: `users`, `exams`, `questions`, `exam_sessions`, `monitoring_events` (diagram's "events"), `risk_scores`, `reviews`, plus `incidents`, `answer_submissions`, `plagiarism_reports`, `notifications`, `audit_logs`, `system_settings`. |
| **Dashboard & Review Layer** | `GET /dashboard/exam/{id}/summary`, `GET /reports/session/{id}`, `PUT /sessions/{id}/review` (Clear / Suspicious / Malpractice Confirmed + comments). |
| **Reports & Analytics** | `GET /reports/session/{id}/pdf` (individual report), `GET /reports/exam/{id}/csv` (exam-wise summary), `GET /reports/session/{id}/risk-trend` (risk trend chart data), `GET /admin/audit-logs` (audit trail). |
| **External Integrations** | `app/integrations/email_service.py` (SMTP, real code, no-op until configured), `app/integrations/storage_service.py` (evidence snapshots to local disk, swappable for S3). SMS and AI-model-versioning are documented extension points only. |
| **Admin** | `app/routers/admin_routes.py` — user activate/deactivate, audit logs, system settings. |

## Data Collection channels — what's real vs. simulated

| Channel | Diagram sub-items | Real or simulated | Notes |
|---|---|---|---|
| **Video** | Face Detection, Multiple Person, Phone Detection, Gaze/Head Pose, Object Detection | **Face count: real** (OpenCV Haar cascade). **Gaze: real heuristic** (face-bbox offset from frame center — no landmark model needed). **Phone detection: simulated heuristic** (dark-rectangle contour matching; stand-in for a real YOLOv8/MediaPipe object detector). |
| **Audio** | Voice Activity, Multiple Voice, Unusual Sounds, Noise Detection | **Simulated heuristic.** Thresholds on a client-reported volume level (Web Audio API) and an optional voice-count hint. No real speech/diarization model. |
| **Screen** | Tab Switch, Fullscreen Exit, Copy/Paste, Right Click, Window Focus | **Real, deterministic.** The exam page reports concrete DOM events; the backend just validates and logs them. |
| **Screen (extension)** | prohibited app / multiple monitors | **Simulated heuristic.** Blocklist match on client-reported window titles; a real system needs a native desktop agent. |
| **Behavior** | Idle Time, Rapid Answering, Backtracking, Abnormal Patterns | **Real**, computed directly from actual event/answer timestamps already stored — no simulation involved, just threshold logic. `abnormal_pattern_detected` is the pipeline's own fused, cross-channel meta-event (see Evidence Fusion below). |
| **Plagiarism** | (Behavior/User Interactions in diagram, handled separately here) | **Real NLP.** TF-IDF + cosine similarity (scikit-learn) across every pair of answers to the same question. |

## Evidence Fusion & Risk Scoring Pipeline (`app/risk_engine.py`)

Every event runs through six stages, matching the diagram exactly:

1. **Preprocessing** — clamp confidence, normalize details.
2. **Temporal Analysis** — if the same `(channel, event_type)` repeats 3+
   times within a rolling window (default 120s), its weight is escalated
   ×1.5 and the reason is recorded.
3. **Risk Scoring** — `weighted_impact = weight × confidence`, deducted from
   the session's `integrity_score` (starts at 100).
4. **Risk Level** — score mapped to `low / medium / high / critical`
   (thresholds in `app/config.py`).
5. **Explainable Output** — a human-readable `reasons` list is attached to
   every event and incident (e.g. *"'tab_switch' on screen channel
   repeated 3 times in the last 120s — escalated."*).
6. **Evidence Fusion** — after each event, the pipeline checks whether 3+
   high/critical events (from any channel combination) landed in the same
   window. If so, it raises a single fused `behavior/abnormal_pattern_detected`
   event instead of leaving the proctor to piece scattered alerts together.

Every score change is also logged to `risk_scores` (`RiskScoreHistory`) so
`GET /reports/session/{id}/risk-trend` can chart the session over time.

### Risk scoring reference (actual computed severity = weight × detector confidence)

Only **high/critical** severity opens an Incident (+ notification + email
alert). Lower severities still deduct score and appear in the event log,
but don't page anyone on their own — they escalate to high/critical either
by repeating 3+ times in the temporal window (×1.5 weight) or by
contributing to a fused cross-channel `abnormal_pattern_detected`.

| Channel | Event | Weight | Confidence | Impact | First-time severity |
|---|---|:---:|:---:|:---:|---|
| video | camera_obstructed | 6 | 0.70 | 4.2 | low |
| video | no_face_detected | 8 | 0.90 | 7.2 | medium |
| video | multiple_faces_detected | 15 | 0.90 | 13.5 | **high — opens incident** |
| video | gaze_away_detected | 5 | 0.55 | 2.75 | low |
| video | phone_detected | 14 | 0.45 | 6.3 | medium |
| audio | audio_spike_detected | 5 | 0.60 | 3.0 | low |
| audio | voice_activity_detected | 8 | 0.65 | 5.2 | low |
| audio | multiple_voice_detected | 12 | 0.60 | 7.2 | medium |
| screen | tab_switch | 5 | 1.00 | 5.0 | low |
| screen | window_blur | 4 | 1.00 | 4.0 | low |
| screen | copy_detected | 6 | 1.00 | 6.0 | medium |
| screen | paste_detected | 8 | 1.00 | 8.0 | medium |
| screen | devtools_opened | 20 | 1.00 | 20.0 | **critical — opens incident** |
| screen | fullscreen_exit | 10 | 1.00 | 10.0 | medium |
| screen | right_click_attempt | 2 | 1.00 | 2.0 | low |
| screen | prohibited_application_detected | 20 | 0.80 | 16.0 | **high — opens incident** |
| screen | multiple_monitors_suspected | 12 | 0.70 | 8.4 | medium |
| behavior | idle_time_exceeded | 6 | 0.75 | 4.5 | low |
| behavior | rapid_answering_detected | 8 | 0.55 | 4.4 | low |
| behavior | backtracking_detected | 4 | 0.50 | 2.0 | low |
| behavior | abnormal_pattern_detected (fusion) | 18 | 0.80 | 14.4 | **high — opens incident** |

After a 3rd repeat within the 120s window (×1.5 weight), several more
cross into high/critical — e.g. `multiple_faces_detected` → critical
(20.25), `fullscreen_exit` → high (15.0), `prohibited_application_detected`
→ critical (24.0). Tune `EVENT_WEIGHTS` and the confidence values in each
`app/detection/*.py` module, or the thresholds in `app/config.py`, to
change this balance.

## Project layout

```
app/
├── main.py                   # FastAPI app, router registration, CORS
├── config.py                  # env-based settings incl. pipeline thresholds
├── database.py                  # SQLAlchemy engine/session (SQLite default, MySQL-ready)
├── models.py                     # ORM models — see Data Storage table above
├── schemas.py                     # Pydantic request/response models
├── auth.py                         # JWT auth + bcrypt hashing + role dependencies + is_active check
├── risk_engine.py                   # Evidence Fusion & Risk Scoring Pipeline
├── websocket_manager.py               # tracks proctor dashboard connections
├── detection/
│   ├── video_analysis.py                # real face detection + heuristic gaze/phone
│   ├── audio_heuristic.py                 # simulated VAD/spike/multi-voice thresholds
│   ├── screen_heuristic.py                  # simulated blocklist/multi-monitor checks
│   ├── browser_events.py                      # real deterministic event validation
│   ├── behavior_heuristic.py                    # real idle/rapid-answer/backtracking checks
│   └── plagiarism_check.py                        # real TF-IDF similarity
├── integrations/
│   ├── email_service.py                             # SMTP alert sender (no-op until configured)
│   └── storage_service.py                             # evidence snapshot storage (local disk)
└── routers/
    ├── auth_routes.py        # Auth Service
    ├── exams.py                # Exam Service (+ question bank)
    ├── sessions.py               # Session Service
    ├── monitoring.py               # Event Service + AI Service (ingests all 4 channels)
    ├── incidents.py                  # incident list/resolve
    ├── plagiarism.py                    # answer submission + plagiarism check
    ├── reviews.py                         # Human Review & Decision
    ├── dashboard.py                          # live summary + proctor WebSocket
    ├── reports.py                              # Report Service (PDF/CSV/JSON/trend)
    ├── notifications.py                          # Notification Service (in-app inbox)
    └── admin_routes.py                             # Admin: users, audit logs, settings
seed_data.py                # demo admin/proctor/students/exam/questions
requirements.txt
.env.example
```

## Setup

```bash
cd exam_integrity_backend
python3 -m venv venv && source venv/bin/activate   # optional but recommended
pip install -r requirements.txt

cp .env.example .env     # edit SECRET_KEY for anything beyond local testing

# optional: pre-populate a demo admin/proctor/2 students/exam/questions
python seed_data.py

uvicorn app.main:app --reload
```

The API is live at `http://127.0.0.1:8000`, with interactive Swagger docs
at `http://127.0.0.1:8000/docs`.

### Switching to MySQL (as shown in the diagram)

```bash
pip install pymysql cryptography   # (already listed, commented, in requirements.txt)
```
```
# .env
DATABASE_URL=mysql+pymysql://user:password@localhost:3306/exam_integrity
```
No code changes needed — `app/database.py` reads `DATABASE_URL` directly.
Create the database first (`CREATE DATABASE exam_integrity;`); tables are
created automatically on first run.

## Typical flow

1. `POST /auth/register` — create an `admin`, a `proctor`, and some
   `student` accounts. `POST /auth/login` for a JWT (`Authorization: Bearer
   <token>` on every subsequent request).
2. Proctor: `POST /exams`, `POST /exams/{id}/questions`,
   `POST /exams/{id}/enroll`.
3. Student: `POST /sessions/start` → `session_id`.
4. During the exam, the client periodically calls:
   - `POST /monitoring/{session_id}/webcam-frame` (base64 JPEG)
   - `POST /monitoring/{session_id}/audio-level` (volume reading)
   - `POST /monitoring/{session_id}/browser-event` (on each DOM event)
   - `POST /monitoring/{session_id}/screen-metadata` (periodically)
   - `POST /monitoring/{session_id}/heartbeat` (periodically, drives idle detection)
   - `POST /sessions/{session_id}/answers` (per question — also runs the
     Behavior channel's rapid-answering/backtracking checks)
5. Proctor dashboard: `ws://127.0.0.1:8000/ws/proctor/{exam_id}?token=<JWT>`
   for live pushes, `GET /dashboard/exam/{exam_id}/summary` for the
   aggregate view, `GET /notifications` for the persisted alert inbox.
6. Proctor: `POST /exams/{exam_id}/plagiarism-check`, then
   `GET /exams/{exam_id}/plagiarism-report`.
7. Proctor: review a flagged session — `GET /reports/session/{id}` (full
   JSON), `GET /reports/session/{id}/pdf` (downloadable report),
   `GET /reports/session/{id}/risk-trend` (chart data), then
   `PUT /sessions/{id}/review` to record Clear / Suspicious / Malpractice
   Confirmed with comments.
8. Admin: `GET /admin/users`, `PATCH /admin/users/{id}/deactivate`,
   `GET /admin/audit-logs`, `PUT /admin/settings/{key}`.
9. `POST /sessions/{session_id}/end` when the student submits.
10. `GET /reports/exam/{exam_id}/csv` for the exam-wide summary export.

## How to check every feature

### Option A — watch a live exam happen (best answer to "how do I check this while examining someone")

This is the one that actually matches the question: it starts a real
proctor WebSocket connection and a real student session, then plays out
~15 seconds of realistic exam-taking — including a student who starts
clean, then leaves the camera frame, gets a second voice picked up, tab-
switches, opens devtools, and gets a prohibited app detected on a second
monitor — while printing every alert the instant the proctor would see it.
At the end it submits a human review decision and downloads a PDF report,
exactly like a real proctor would.

```bash
# Terminal 1
uvicorn app.main:app --reload

# Terminal 2
pip install -r requirements-dev.txt    # adds httpx, used only by this script
python simulate_live_exam.py
```

Sample transcript (yours will have live timestamps):
```
[08:02:45] SYSTEM    | exam_id=1  session_id=1
[08:02:45] PROCTOR   | connected to live alert feed, watching...
[08:02:46] STUDENT   | exam window opened, webcam/mic active
[08:02:46] PROCTOR   |   event   | video/no_face_detected     severity=medium score=92.8 risk=low
[08:02:46] STUDENT   | answering Q1 normally
[08:02:47] STUDENT   | *leaves the camera frame*
[08:02:47] PROCTOR   |   event   | video/camera_obstructed    severity=low    score=84.2 risk=medium
[08:02:49] STUDENT   | *talking to someone off-screen*
[08:02:49] PROCTOR   |   event   | audio/multiple_voice_detected severity=medium score=74.0 risk=medium
[08:02:50] STUDENT   | *switches tabs 3 times, then opens devtools*
[08:02:51] PROCTOR   | 🚨 INCIDENT | screen/devtools_opened     severity=critical score=36.5 risk=critical
[08:02:53] STUDENT   | *WhatsApp open on a second monitor*
[08:02:53] PROCTOR   | 🚨 INCIDENT | screen/prohibited_application_detected severity=high score=20.5 risk=critical
...
[08:02:57] PROCTOR   | final integrity_score=5.7  risk_level=critical
[08:02:57] PROCTOR   | 2 incident(s) recorded: Devtools Opened, Prohibited Application Detected
[08:02:57] PROCTOR   | review submitted: malpractice_confirmed
[08:02:58] PROCTOR   | downloaded PDF report (2415 bytes) -> live_simulation_report.pdf
```
Open `live_simulation_report.pdf` afterward — it's a real, readable report
generated from the exact events in the transcript above.

### Option B — automated pytest suite (fastest, verifies all 36 features in ~5 seconds)

```bash
pip install -r requirements-dev.txt
pytest tests/test_all_features.py -v
```

Each test name is a feature from the architecture diagram — a passing run
means auth, exam/question management, session lifecycle, all 4 detection
channels, temporal escalation, cross-channel evidence fusion, plagiarism
detection, human review, notifications, all 3 report formats, incident
resolution, admin user/audit/settings management, the dashboard summary,
and the live WebSocket push all work end to end. It uses a disposable
`test_exam_integrity.db` (deleted/recreated on each run) so it never
touches your real database.

### Option C — manual, via Swagger UI (`/docs`)

Good for actually demonstrating the system to an evaluator. Run
`python seed_data.py` first for ready-made accounts, then:

1. **Auth** — `POST /auth/login` with `proctor@demo.com` / `proctor123`
   (form fields `username`/`password`). Copy the `access_token`, click the
   🔒 **Authorize** button top-right of `/docs`, paste it in as
   `Bearer <token>` (or just the raw token — Swagger adds the prefix).
2. **Exam Service** — `GET /exams` to see the seeded exam,
   `POST /exams/{id}/questions` to add one, `PATCH /exams/{id}` to edit it.
3. **Session Service** — log in as `alice@demo.com` / `student123`,
   `POST /sessions/start` with the exam ID from step 2. Note the returned
   `session_id` — every monitoring call below needs it.
4. **Video channel** — `POST /monitoring/{session_id}/webcam-frame` with
   any base64 JPEG (even a plain black square — you'll see
   `camera_obstructed` come back; a bright image with no face gives
   `no_face_detected`).
5. **Audio channel** — `POST /monitoring/{session_id}/audio-level` with
   `{"amplitude": 90, "sustained_seconds": 1, "voice_count_estimate": 2}`
   → returns `audio_spike_detected` + `multiple_voice_detected`.
6. **Screen channel** — `POST /monitoring/{session_id}/browser-event` with
   `{"event_type": "devtools_opened"}` → critical incident, visible next
   in `GET /exams/{exam_id}/incidents` (log back in as proctor).
7. **Behavior channel** — `POST /sessions/{session_id}/answers` twice with
   the same `question_id` (as the student) → second call has
   `"is_edit": true`; check `GET /monitoring/{session_id}/events` for
   `backtracking_detected` / `rapid_answering_detected`.
8. **Temporal escalation** — repeat any browser event 3× within a couple
   of minutes; its 3rd occurrence's `reasons` field will say "escalated".
9. **Evidence Fusion** — trigger 3 high/critical-severity events (e.g. two
   `screen-metadata` calls with a blocked app + one `devtools_opened`)
   within 120 seconds → a `behavior/abnormal_pattern_detected` event
   appears automatically in the event list.
10. **Plagiarism** — submit similar answer text from two students to the
    same `question_id`, then (as proctor) `POST /exams/{exam_id}/plagiarism-check`
    followed by `GET /exams/{exam_id}/plagiarism-report`.
11. **Human Review** — as proctor, `PUT /sessions/{session_id}/review` with
    `{"decision": "suspicious", "comments": "..."}`.
12. **Notifications** — as proctor, `GET /notifications` — one entry per
    incident raised in steps 6–9.
13. **Reports** — as proctor: `GET /reports/session/{session_id}` (full
    JSON), `GET /reports/session/{session_id}/pdf` (downloads a PDF —
    Swagger's "Download file" link), `GET /reports/exam/{exam_id}/csv`,
    `GET /reports/session/{session_id}/risk-trend`.
14. **Admin** — log in as `admin@demo.com` / `admin123` (register one via
    `/auth/register` with `"role": "admin"` if you didn't run the seed
    script): `GET /admin/users`, `PATCH /admin/users/{id}/deactivate`,
    `GET /admin/audit-logs`, `PUT /admin/settings/{key}`.
15. **Live WebSocket alerts** — outside Swagger (it can't do WS), use a
    tool like `websocat` or a browser console:
    `wscat -c "ws://127.0.0.1:8000/ws/proctor/{exam_id}?token=<proctor JWT>"`,
    then trigger any monitoring event from another terminal/tab — the
    alert appears in the socket instantly.
16. **RBAC** — try any proctor-only or admin-only endpoint while logged in
    as a student; every one should return `403`.



- **Client Layer / frontend**: this repo is backend-only. Pair it with a
  React or plain-JS exam page that captures webcam frames (`getUserMedia`
  + canvas), a volume meter (`AnalyserNode`), and DOM event listeners.
- **Real object detection**: `phone_detected` uses a contour heuristic, not
  a trained model. Swap `app/detection/video_analysis.py`'s
  `_detect_phone_like_object` for a YOLOv8/MediaPipe call — the rest of
  the pipeline (weighting, fusion, incidents) needs no changes.
- **Real audio/speaker diarization**: `audio_heuristic.py` is threshold-based.
  Swap for a real VAD/diarization model behind the same function signature.
- **Face identity verification** (matching webcam face to a registered ID
  photo) isn't implemented — Haar cascades detect *that* a face is
  present, not *whose*. `face_recognition`/`dlib` embeddings would be the
  natural next step.
- **SMS alerts / AI model versioning**: documented as extension points in
  the architecture table above; no code stub included since there's
  nothing meaningful to test without a real provider.
- Passwords are hashed with `bcrypt` directly (not via `passlib`) to avoid
  a known passlib/bcrypt 4.x+ incompatibility.
